
from datetime import datetime, timezone
from typing import Optional
from aiosqlite import Connection
from database.setup import Database

#Тут пишите Функции базы данных

async def create_user(
    conn: Connection,
    user_id: int,
    username: Optional[str] = None,
    ref_by: Optional[int] = None
) -> None:
    query_check = "SELECT 1 FROM users WHERE user_id = ?;"
    cursor = await conn.execute(query_check, (user_id,))
    exists = await cursor.fetchone()
    if exists:
        return

    query_insert = """
    INSERT INTO users (user_id, username, ref_by, registered_at, balance)
    VALUES (?, ?, ?, ?, ?);
    """
    registered_at = datetime.now(timezone.utc).isoformat()
    initial_balance = 100

    await conn.execute(query_insert, (user_id, username, ref_by, registered_at, initial_balance))
    await conn.commit()

async def get_user_by_id(conn: Connection, user_id: int) -> Optional[dict]:
    conn.row_factory = lambda cursor, row: {col[0]: row[idx] for idx, col in enumerate(cursor.description)}
    async with conn.execute("SELECT * FROM users WHERE user_id = ?", (user_id,)) as cursor:
        row = await cursor.fetchone()
        return row
    

async def get_last_bonus_time(conn: Connection, user_id: int, bonus_type: str) -> Optional[datetime]:
    query = """
    SELECT claimed_at
    FROM bonus_claims
    WHERE user_id = ? AND type = ?
    ORDER BY claimed_at DESC
    LIMIT 1
    """
    async with conn.execute(query, (user_id, bonus_type)) as cursor:
        row = await cursor.fetchone()
        return datetime.fromisoformat(row[0]) if row and row[0] else None


async def update_last_bonus_time(conn: Connection, user_id: int, bonus_type: str) -> None:
    now = datetime.now().isoformat()
    query = """
    INSERT INTO bonus_claims (user_id, type, claimed_at)
    VALUES (?, ?, ?)
    """
    await conn.execute(query, (user_id, bonus_type, now))
    await conn.commit()

async def get_user(db: Database, user_id: int):
    query = "SELECT * FROM users WHERE user_id = ?"
    return await db.fetchrow(query, (user_id,))


async def update_user_balance(self, user_id: int, new_balance: int):
    await self._conn.execute(
        "UPDATE users SET balance = ? WHERE user_id = ?",
        (new_balance, user_id)
    )
    await self._conn.commit()


async def get_deposit_account(db: Database, user_id: int):
    query = "SELECT * FROM deposit_accounts WHERE user_id = ?"
    return await db.fetchrow(query, (user_id,))

async def add_kazna_balance(conn, amount: int):
    """
    Прибавляет указанную сумму к балансу государственной казны.

    :param conn: активное подключение aiosqlite
    :param amount: сумма для добавления (может быть отрицательной)
    """
    await conn.execute(
        "UPDATE bank_treasury SET balance = balance + ? WHERE id = 1",
        (amount,)
    )
    await conn.commit()


#Если казна потерялась
async def init_treasury(db):
    await db.connect()
    try:
        await db._conn.execute(
            "INSERT OR IGNORE INTO bank_treasury (id, balance) VALUES (1, 0)"
        )
        await db._conn.commit()
    finally:
        await db.close()

    
async def create_bank_account(db, user_id: int):
    await db.execute(
        """
        INSERT INTO bank_accounts (user_id, balance, deposit, deposit_start, last_interest, daily_limit, last_transfer)
        VALUES (?, 0, 0, NULL, NULL, 0, NULL)
        """,
        (user_id,)
    )

async def update_bank_account(db, user_id: int, new_balance: int = None, **fields):
    if new_balance is not None:
        fields["balance"] = new_balance

    if not fields:
        return

    set_clause = ", ".join(f"{field} = ?" for field in fields)
    values = list(fields.values())
    values.append(user_id)

    await db.execute(
        f"""
        UPDATE bank_accounts
        SET {set_clause}
        WHERE user_id = ?
        """,
        values
    )


async def update_deposit_info(db, user_id: int, deposit: int, start: datetime, last: datetime, procent: float):
    await db.execute(
        "UPDATE bank_accounts SET deposit = ?, deposit_start = ?, last_interest = ?, procent = ? WHERE user_id = ?",
        (deposit, start, last, procent, user_id)
    )

async def reset_deposit(db, user_id: int):
    await db.execute(
        "UPDATE bank_accounts SET deposit = 0, deposit_start = NULL, last_interest = NULL, procent = 0 WHERE user_id = ?",
        (user_id,)
    )

def parse_datetime(value):
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    try:
        return datetime.fromisoformat(value)
    except Exception:
        return None

async def get_bank_account(db: Database, user_id: int):
    query = "SELECT * FROM bank_accounts WHERE user_id = ?"
    row = await db.fetchrow(query, (user_id,))
    if not row:
        return None

    account = dict(row)  # Копируем в изменяемый словарь

    account['deposit_start'] = parse_datetime(account['deposit_start'])
    account['last_interest'] = parse_datetime(account['last_interest'])
    return account


async def get_bonus_claims(db: Database, user_id: int) -> list[dict]:
    query = """
        SELECT type, claimed_at
        FROM bonus_claims
        WHERE user_id = ?
    """
    rows = await db.fetchall(query, (user_id,))
    return [{"type": row[0], "claimed_at": row[1]} for row in rows]


async def get_referrals(db: Database, user_id: int) -> list[dict]:
    query = """
        SELECT invited, rewarded, created_at
        FROM referrals
        WHERE user_id = ?
    """
    rows = await db.fetchall(query, (user_id,))
    return [{"invited": row[0], "rewarded": bool(row[1]), "created_at": row[2]} for row in rows]


async def get_games_stats(db: Database, user_id: int) -> dict:
    # Собираем количество сыгранных игр и статистику по статусам
    query_total = """
        SELECT COUNT(*) FROM games WHERE user_id = ?
    """
    query_wins = """
        SELECT COUNT(*) FROM games WHERE user_id = ? AND status = 'win'
    """
    query_losses = """
        SELECT COUNT(*) FROM games WHERE user_id = ? AND status = 'lose'
    """

    total = (await db.fetchone(query_total, (user_id,)))[0] or 0
    wins = (await db.fetchone(query_wins, (user_id,)))[0] or 0
    losses = (await db.fetchone(query_losses, (user_id,)))[0] or 0

    return {
        "total": total,
        "wins": wins,
        "losses": losses,
    }


async def set_user_ban_status(db: Database, user_id: int, ban_status: bool):
    await db.execute("UPDATE users SET is_banned = ? WHERE user_id = ?", (ban_status, user_id))


async def delete_user_account(db: Database, user_id: int):
    # Важно удалить записи во всех связанных таблицах, чтобы избежать "висячих" данных
    queries = [
        ("DELETE FROM bank_accounts WHERE user_id = ?", user_id),
        ("DELETE FROM bonus_claims WHERE user_id = ?", user_id),
        ("DELETE FROM referrals WHERE user_id = ? OR invited = ?", (user_id, user_id)),
        ("DELETE FROM games WHERE user_id = ?", user_id),
        ("DELETE FROM promocode_claims WHERE user_id = ?", user_id),
        ("DELETE FROM transfers WHERE from_user_id = ? OR to_user_id = ?", (user_id, user_id)),
        ("DELETE FROM users WHERE user_id = ?", user_id),
    ]
    for query in queries:
        if isinstance(query[1], tuple):
            await db.execute(query[0], query[1])
        else:
            await db.execute(query[0], (query[1],))

async def update_user_duel_stats(db: Database, user_id: int, duels_won: int = 0, duel_wins: int = 0):
    query = """
        UPDATE users
        SET duels_won = duels_won + ?,
            duel_wins = duel_wins + ?
        WHERE user_id = ?
    """
    await db.execute(query, (duels_won, duel_wins, user_id))
    await db._conn.commit()