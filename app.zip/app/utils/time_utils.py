from datetime import datetime, timedelta


def get_now() -> datetime:
    return datetime.utcnow()


def get_remaining_time(target: datetime) -> str:
    now = get_now()
    if target <= now:
        return "0д 0ч 0м"

    delta = target - now
    days = delta.days
    hours, remainder = divmod(delta.seconds, 3600)
    minutes = remainder // 60

    return f"{days}д {hours}ч {minutes}м"


def parse_duration(duration: str) -> timedelta:
    """
    Парсит строку вида "1d", "3w", "1m", "3m" и возвращает timedelta.
    """
    mapping = {
        'd': 1,
        'w': 7,
        'm': 30  # Условный месяц — 30 дней
    }
    
    suffix = duration[-1].lower()
    number = int(duration[:-1])
    
    if suffix not in mapping:
        raise ValueError("Неверный формат срока")
    
    return timedelta(days=number * mapping[suffix])


def format_amount(amount: int | float) -> str:
    """
    Форматирует число с пробелами как разделителями тысяч.

    Примеры:
    - 1000 -> '1 000'
    - 1250000 -> '1 250 000'
    """
    return f"{int(amount):,}".replace(",", " ")
