import asyncio
import logging
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger

from database.setup import Database
from config import load_config

config = load_config()
db = Database(config.bot.database)

SALARY_MAP = {
    6: {"donatecoin": 6336},        
    5: {"balance": 12_000_000},       
    4: {"balance": 9_600_000},
    3: {"balance": 7_000_000},
    2: {"balance": 2_500_000},
    1: {"balance": 0}
}

async def pay_admin_salaries():
    print("Начинаем выплату зарплат админам")
    try:
        admins = await db.fetchall("SELECT user_id, level FROM admins")
        for admin in admins:
            user_id = admin["user_id"]
            level = admin["level"]
            salary = SALARY_MAP.get(level, {})

            if "balance" in salary:
                await db.execute(
                    "UPDATE users SET balance = balance + ? WHERE user_id = ?", 
                    (salary["balance"], user_id)
                )
            if "donatecoin" in salary:
                await db.execute(
                    "UPDATE users SET donatecoin = donatecoin + ? WHERE user_id = ?", 
                    (salary["donatecoin"], user_id)
                )
        print("✅ Зарплаты админам успешно выплачены")
    except Exception as e:
        logging.exception(f"❌ Ошибка при выплате зарплат: {e}")

def run_async_job(coro):
    """
    Запускает асинхронную корутину в event loop,
    создавая новый, если текущего нет
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(coro)
    else:
        asyncio.ensure_future(coro, loop=loop)

def setup_scheduler():
    scheduler = AsyncIOScheduler(timezone="Asia/Yekaterinburg")

    def job_wrapper():
        run_async_job(pay_admin_salaries())

    scheduler.add_job(job_wrapper, CronTrigger(hour=17, minute=30))
    scheduler.start()
    print("Scheduler для выплаты зарплат админам запущен")
