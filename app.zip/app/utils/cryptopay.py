from aiocryptopay import AioCryptoPay, Networks
from config import load_config

config = load_config()

# Инициализация клиента
crypto = AioCryptoPay(token=config.crypto.token, network=Networks.MAIN_NET)


async def is_invoice_paid(invoice_id: int) -> bool:
    """
    Проверяет, был ли оплачено счёт с указанным invoice_id.

    :param invoice_id: ID инвойса, выданного Cryptopay.
    :return: True, если статус == 'paid', иначе False.
    """
    try:
        invoices = await crypto.get_invoices(invoice_ids=[invoice_id])
        if invoices.items and invoices.items[0].status == "paid":
            return True
    except Exception:
        pass
    return False

async def create_invoice(amount: float, asset: str = "USDT", comment: str = "") -> str | None:
    try:
        invoice = await crypto.create_invoice(
            amount=amount,
            asset=asset,
            comment=comment
        )
        return invoice.pay_url
    except Exception:
        return None