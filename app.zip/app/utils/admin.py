async def get_admin_level(db, user_id: int) -> int | None:
    """
    Эта хуйня возвращает уровень админа (1-3) если пользователь есть в таблице admins,
    иначе пизданет None.
    """
    query = "SELECT level FROM admins WHERE user_id = ?"
    row = await db.fetchone(query, (user_id,))
    if row:
        return row["level"]
    return None

async def is_admin(db, user_id: int) -> bool:
    level = await get_admin_level(db, user_id)
    return level is not None

def get_role_name_by_level(level: int | None) -> str:
    if level == 6:
        return "👑 Владелец"
    elif level and level >= 1:
        return "🔧 Админ"
    return "🧑 Игрок"