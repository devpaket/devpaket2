from dotenv import load_dotenv
from os import getenv
from dataclasses import dataclass

load_dotenv()

@dataclass
class BotConfig:
    token: str
    database: str
    bot_username: str
    owner_id: str
    admin_chat: str

@dataclass
class CryptoConfig:
    token: str

@dataclass
class Config:
    bot: BotConfig
    crypto: CryptoConfig

def load_config() -> Config:
    return Config(
        bot=BotConfig(
            token=getenv("BOT_TOKEN"),
            database=getenv("DB_PATH"),
            bot_username=getenv("BOT_USERNAME"),
            owner_id=getenv("OWNER_ID"),
            admin_chat=getenv("ADMIN_CHAT_ID")
        ),
        crypto=CryptoConfig(
            token=getenv("CRYPTO_TOKEN")
        )
    )
