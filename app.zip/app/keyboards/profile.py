from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from config import load_config

config = load_config()

def bonus_options_keyboard(userid: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="Лотерея 💼", callback_data=f"lottery_play:{userid}")
            ],
            [
                InlineKeyboardButton(text="🏝️ Ежедневный бонус", callback_data=f"daily_gift_check:{userid}")
            ],
        ]
    )

def invite_bot_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="➕ Добавить в группу",
                    url=f"https://t.me/{config.bot.bot_username}?startgroup=start"
                )
            ]
        ]
    )

def lottery_keyboard(user_id: int, winning_index: int):
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🎁", callback_data=f"lottery:{user_id}:{winning_index}:0"),
            InlineKeyboardButton(text="🎁", callback_data=f"lottery:{user_id}:{winning_index}:1"),
            InlineKeyboardButton(text="🎁", callback_data=f"lottery:{user_id}:{winning_index}:2"),
        ]
    ])