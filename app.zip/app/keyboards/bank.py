from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def bank_keyboard(user_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="➕ Пополнить", callback_data=f"bank_add:{user_id}"),
                InlineKeyboardButton(text="➖ Вывести", callback_data=f"bank_withdraw:{user_id}")
            ],
            [
                InlineKeyboardButton(text="💱 Перевести", callback_data=f"bank_pay:{user_id}")
            ],
            [
                InlineKeyboardButton(text="🏦 Депозит", callback_data=f"bank_deposit:{user_id}")
            ],
        ]
    )


def back_to_bank_menu_keyboard(user_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔙 Назад", callback_data=f"bank_menu:{user_id}")]
    ])