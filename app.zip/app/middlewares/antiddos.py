import time
from aiogram import BaseMiddleware, Bot
from aiogram.types import TelegramObject, Message
from aiogram.exceptions import TelegramForbiddenError
from typing import Callable, Any, Dict
from config import load_config

config = load_config()

class AntiFloodMiddleware(BaseMiddleware):
    def __init__(self, bot: Bot, limit_per_sec: float = 1.0, mute_seconds: float = 15.0):
        self.bot = bot
        self.limit = limit_per_sec
        self.mute_seconds = mute_seconds
        self.last_message_time: dict[int, float] = {}
        self.muted_users: dict[int, float] = {}
        self.message_counts: dict[int, list[float]] = {}

    async def __call__(self, handler: Callable, event: TelegramObject, data: Dict[str, Any]):
        user = data.get('event_from_user')
        if not user:
            return await handler(event, data)

        user_id = user.id
        now = time.time()

        mute_until = self.muted_users.get(user_id)
        if mute_until:
            if now < mute_until:
                return
            else:
                del self.muted_users[user_id]

        timestamps = self.message_counts.get(user_id, [])
        timestamps = [ts for ts in timestamps if now - ts < 1.0]
        timestamps.append(now)
        self.message_counts[user_id] = timestamps
        messages_per_sec = len(timestamps)

        last_time = self.last_message_time.get(user_id, 0)
        delta = now - last_time

        if delta < self.limit:
            self.muted_users[user_id] = now + self.mute_seconds

            if isinstance(event, Message):
                try:
                    await event.answer(
                        f"<b>⛔ Вы слишком часто отправляете сообщения</b>\n"
                        f"<b>⌛ Мьют:</b> <code>{self.mute_seconds} сек</code>",
                        parse_mode="HTML"
                    )
                except TelegramForbiddenError:
                    pass

            try:
                await self.bot.send_message(
                    chat_id=config.bot.admin_chat,
                    text=(
                        f"<b>🚨 Анти-Флуд</b>\n"
                        f"<code>────────────────────────</code>\n"
                        f"👤 Пользователь: <a href='tg://user?id={user_id}'>{user.full_name}</a> | <code>{user_id}</code>\n"
                        f"⚡ Сообщений в секунду: <code>{messages_per_sec}</code>\n"
                        f"<code>────────────────────────</code>"
                    ),
                    parse_mode="HTML"
                )
            except TelegramForbiddenError:
                pass

            return

        self.last_message_time[user_id] = now
        return await handler(event, data)
