from aiogram import Router, F
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import Command, or_f
from aiogram.enums.parse_mode import ParseMode
from database.queries import get_user_by_id, create_user, update_user_balance, add_kazna_balance
from database.setup import Database
from aiogram.types import CallbackQuery
from config import load_config

router = Router()
config = load_config()
db = Database(config.bot.database)
print("[Log] Router Refferal запущен")

def main_referral_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🧬 Топ рефералов", callback_data="top_referrals")],
        [InlineKeyboardButton(text="👥 Мои рефералы", callback_data="my_referrals")],
    ])

# Клавиатура с кнопкой "Назад"
def back_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⬅️ Назад", callback_data="back_to_referral_menu")]
    ])

@router.message(or_f(Command("ref"), F.text.casefold() == "реферал"))
async def referral_handler(message: Message):
    await db.connect()
    user_id = message.from_user.id

    ref_link = f"https://t.me/{config.bot.bot_username}?start=ref_{user_id}"
    ref_count_row = await db.fetchone(
        "SELECT COUNT(*) as total FROM referrals WHERE user_id = ?",
        (user_id,)
    )
    earnings = ref_count_row['total'] * 1000
    rows = await db.fetchall(
        "SELECT invited FROM referrals WHERE user_id = ? AND rewarded = TRUE",
        (user_id,)
    )
    user = message.from_user
    username = user.username
    first_name = user.first_name
    name_link = (
        f"<a href='https://t.me/{username}'>{first_name}</a>"
    )


    await message.answer(
        f"🔗 <b>{name_link}</b>, твоя реферальная ссылка:\n<code>{ref_link}</code>\n"
        f"<code>·····················</code>\n"
        f"💸 <i>Приглашай и получай награды!</i>\n\n"
        f"💜 <i>Твои рефералы: <b>{ref_count_row['total']}</b> чел.</i>\n"
        f"✨ <i>Заработано с рефералов: <b>{earnings}</b> PaketCoins</i>",
        reply_markup=main_referral_keyboard(),
        parse_mode=ParseMode.HTML,
        disable_web_page_preview=True
    )
    await db.close()

@router.callback_query(F.data == "top_referrals")
async def callback_top_referrals(callback: CallbackQuery):
    await db.connect()
    rows = await db.fetchall("""
        SELECT user_id, COUNT(invited) AS invites_count 
        FROM referrals 
        GROUP BY user_id 
        ORDER BY invites_count DESC 
        LIMIT 10
    """)
    text = "🏆 <b>Топ 10 рефералов:</b>\n\n<code>·····················</code>\n"
    if not rows:
        text += "Пока никто не пригласил рефералов."
    else:
        for idx, row in enumerate(rows, start=1):
            user = await db.fetchone("SELECT username FROM users WHERE user_id = ?", (row["user_id"],))
            username = user["username"] if user and user["username"] else f"user_{row['user_id']}"
            text += f"{idx}. @{username} — {row['invites_count']} рефералов\n"
    await callback.message.edit_text(text, parse_mode=ParseMode.HTML, reply_markup=back_keyboard())
    await db.close()
    await callback.answer()

@router.callback_query(F.data == "my_referrals")
async def callback_my_referrals(callback: CallbackQuery):
    user_id = callback.from_user.id
    await db.connect()
    rows = await db.fetchall("""
        SELECT invited, rewarded 
        FROM referrals 
        WHERE user_id = ?
    """, (user_id,))
    if not rows:
        text = "У вас пока нет рефералов."
    else:
        text = "👥 <b>Ваши рефералы:</b>\n <code>·····················</code>\n"
        for row in rows:
            invited_user = await db.fetchone("SELECT username FROM users WHERE user_id = ?", (row["invited"],))
            invited_name = invited_user["username"] if invited_user and invited_user["username"] else f"user_{row['invited']}"
            status = "✅ Получена награда"
            text += f"@{invited_name} — {status}\n"
    await callback.message.edit_text(text, parse_mode=ParseMode.HTML, reply_markup=back_keyboard(), disable_web_page_preview=True)
    await db.close()
    await callback.answer()

@router.callback_query(F.data == "back_to_referral_menu")
async def callback_back_to_menu(callback: CallbackQuery):
    user_id = callback.from_user.id
    await db.connect()

    ref_link = f"https://t.me/{config.bot.bot_username}?start=ref_{user_id}"
    ref_count_row = await db.fetchone(
        "SELECT COUNT(*) as total FROM referrals WHERE user_id = ?",
        (user_id,)
    )
    earnings = ref_count_row['total'] * 1000
    rows = await db.fetchall(
        "SELECT invited FROM referrals WHERE user_id = ? AND rewarded = TRUE",
        (user_id,)
    )

    user = callback.from_user
    username = user.username
    first_name = user.first_name
    name_link = (
        f"<a href='https://t.me/{username}'>{first_name}</a>"
    )

    await callback.message.edit_text(
        f"🔗 <b>{name_link}</b>, твоя реферальная ссылка:\n<code>{ref_link}</code>\n"
        f"<code>·····················</code>\n"
        f"💸 <i>Приглашай и получай награды!</i>\n\n"
        f"💜 <i>Твои рефералы: <b>{ref_count_row['total']}</b> чел.</i>\n"
        f"✨ <i>Заработано с рефералов: <b>{earnings}</b> PaketCoins</i>",
        reply_markup=main_referral_keyboard(),
        parse_mode=ParseMode.HTML,
        disable_web_page_preview=True
    )
    await db.close()
    await callback.answer()