from aiogram import Router, F
from aiogram.filters import Command, or_f
from aiogram.types import Message, CallbackQuery
from aiogram.enums import ParseMode
from database.setup import Database
from config import load_config
from html import escape
import re
from utils.admin import is_admin, get_admin_level
from datetime import datetime, timedelta, timezone
from random import randint
from database.queries import get_last_bonus_time, update_last_bonus_time
from database.queries import get_user_by_id, add_kazna_balance

from keyboards.profile import bonus_options_keyboard, invite_bot_keyboard, lottery_keyboard
from keyboards.top import top_main_keyboard, duel_filter_keyboard, mcoin_keyboard

router = Router()

config = load_config()
db = Database(config.bot.database)
print("[Log] Router Profile запущен")

@router.message(or_f(Command("balance"), F.text.casefold() == "баланс", F.text.casefold() == "б"))
async def balance_handler(message: Message):
    await db.connect()
    user_id = message.from_user.id

    user_query = """
        SELECT balance, duels_won, coins_lost
        FROM users
        WHERE user_id = ?
    """
    async with db._conn.execute(user_query, (user_id,)) as cursor:
        user_row = await cursor.fetchone()

    games_query = """
        SELECT COUNT(*) as games_played
        FROM games
        WHERE user_id = ?
    """
    async with db._conn.execute(games_query, (user_id,)) as cursor:
        games_row = await cursor.fetchone()

    await db.close()

    if user_row and games_row:
        balance, duels_won, coins_lost = user_row
        games_played = games_row["games_played"]

        response_text = (
            f"<i>💰Баланс: {balance} PaketCoin</i>\n"
            f"<code>·····················</code>\n"
            f"<i>💣 Сыграно игр: {games_played}</i>\n"
            f"<i>⚔️ Выиграно дуэлей: {duels_won}</i>\n"
            f"<i>🗿 Проиграно PaketCoin: {coins_lost}</i>"
        )
        await message.answer(response_text, parse_mode=ParseMode.HTML)
    else:
        await message.answer("Пользователь не найден в базе данных.")


@router.message(or_f(Command("bonus"), F.text.casefold() == "бонус"))
async def bonus_handler(message: Message):
    await db.connect()
    user = message.from_user
    username = user.username
    first_name = user.first_name
    name_link = f"<a href='https://t.me/{username}'>{first_name}</a>"
    user_id = user.id

    cursor = await db._conn.execute(
        "SELECT balance FROM users WHERE user_id = ?",
        (user_id,)
    )
    row = await cursor.fetchone()
    await cursor.close()
    balance = row[0] if row else 0

    cursor = await db._conn.execute(
        "SELECT claimed_at FROM bonus_claims WHERE user_id = ? AND type = 'hourly'",
        (user_id,)
    )
    row = await cursor.fetchone()
    await cursor.close()

    now = datetime.now(timezone.utc)

    last_time = None
    if row:
        last_time = datetime.fromisoformat(row[0]).replace(tzinfo=timezone.utc)

    if last_time and (now - last_time).total_seconds() < 3 * 3600:
        remaining = timedelta(hours=3) - (now - last_time)
        hours, remainder = divmod(remaining.seconds, 3600)
        minutes = remainder // 60

        bonus_text = (
            f"🙊<i>{name_link}, ты уже получил бонус! Приходи через</i> "
            f"<i>{hours} ч. {minutes} м.</i> ⏳\n"
            "<code>·····················</code>\n"
            f"<i>💰Баланс: {balance} PaketCoin</i>\n"
            "<blockquote>ℹ️<i> Также ты можешь собрать следующие бонусы </i>👇</blockquote>"
        )

        await message.answer(
            bonus_text,
            parse_mode=ParseMode.HTML,
            disable_web_page_preview=True,
            reply_markup=bonus_options_keyboard(user_id)
        )
        await db.close()
        return

    bonus_amount = randint(100, 600)

    await db._conn.execute(
        "UPDATE users SET balance = balance + ? WHERE user_id = ?",
        (bonus_amount, user_id)
    )

    await db._conn.execute(
        """
        INSERT INTO bonus_claims (user_id, type, claimed_at)
        VALUES (?, 'hourly', CURRENT_TIMESTAMP)
        ON CONFLICT(user_id, type) DO UPDATE SET claimed_at = CURRENT_TIMESTAMP
        """,
        (user_id,)
    )

    await db._conn.commit()

    cursor = await db._conn.execute(
        "SELECT balance FROM users WHERE user_id = ?",
        (user_id,)
    )
    row = await cursor.fetchone()
    await cursor.close()
    balance = row[0] if row else 0
    await add_kazna_balance(db._conn, -int(bonus_amount))

    await db.close()

    text = (
        f"🎁 <i>{name_link}, тебе был выдан бонус в размере: {bonus_amount} PaketCoin</i>!\n"
        f"<code>·····················</code>\n"
        f"💰<i>Баланс: {balance} PaketCoin</i>\n"
        f"<blockquote>ℹ️<i> Также ты можешь собрать следующие бонусы 👇</i></blockquote>"
    )

    await message.answer(
        text,
        parse_mode=ParseMode.HTML,
        reply_markup=bonus_options_keyboard(user_id),
        disable_web_page_preview=True
    )

LOTTERY_REWARD = 1000

async def get_last_bonus_time(conn, user_id: int, bonus_type: str):
    async with conn.execute(
        "SELECT claimed_at FROM bonus_claims WHERE user_id = ? AND type = ?",
        (user_id, bonus_type)
    ) as cursor:
        row = await cursor.fetchone()
        return datetime.fromisoformat(row[0]) if row else None


async def update_last_bonus_time(conn, user_id: int, bonus_type: str):
    await conn.execute(
        """
        INSERT INTO bonus_claims (user_id, type, claimed_at)
        VALUES (?, ?, CURRENT_TIMESTAMP)
        ON CONFLICT(user_id, type) DO UPDATE SET claimed_at = CURRENT_TIMESTAMP
        """,
        (user_id, bonus_type)
    )


@router.callback_query(F.data.startswith("lottery_play:"))
async def lottery_callback_handler(callback: CallbackQuery):
    await db.connect()
    user_id = callback.from_user.id
    username = callback.from_user.username
    first_name = callback.from_user.first_name
    name_link = f"<a href='https://t.me/{username}'>{first_name}</a>"

    data = callback.data
    _, chatid_str = data.split(":")

    cursor = await db._conn.execute(
        "SELECT claimed_at FROM bonus_claims WHERE user_id = ? AND type = 'daily'",
        (user_id,)
    )
    row = await cursor.fetchone()
    await cursor.close()

    now = datetime.now()
    if row:
        last_time = datetime.fromisoformat(row[0])
        if last_time.date() == now.date():
            await callback.message.answer(
                f"📛 <i>{name_link}, ты уже участвовал в лотерее сегодня. Приходи завтра!</i>",
                parse_mode=ParseMode.HTML, disable_web_page_preview=True
            )
            await db.close()
            await callback.answer()
            return

    winning = randint(0, 2)
    await callback.message.answer(
        f"🎲 <i>{name_link}, выбери один из сундуков! В одном из них спрятано {LOTTERY_REWARD} PaketCoin 💰</i>",
        parse_mode=ParseMode.HTML,
        disable_web_page_preview=True,
        reply_markup=lottery_keyboard(user_id, winning)
    )

    await db.close()
    await callback.answer()


@router.message(or_f(Command("lottery"), F.text.casefold() == "лотерея"))
async def lottery_command(message: Message):
    await db.connect()
    user_id = message.from_user.id
    username = message.from_user.username
    first_name = message.from_user.first_name
    name_link = f"<a href='https://t.me/{username}'>{first_name}</a>"
    
    cursor = await db._conn.execute(
        "SELECT claimed_at FROM bonus_claims WHERE user_id = ? AND type = 'daily'",
        (user_id,)
    )
    row = await cursor.fetchone()
    await cursor.close()

    now = datetime.now()
    if row:
        last_time = datetime.fromisoformat(row[0])
        if last_time.date() == now.date():
            await message.answer(
                f"📛 <i>{name_link}, ты уже участвовал в лотерее сегодня. Приходи завтра!</i>",
                parse_mode=ParseMode.HTML, disable_web_page_preview=True
            )
            await db.close()
            return

    winning = randint(0, 2)
    await message.answer(
        f"🎲 <i>{name_link}, выбери один из сундуков! В одном из них спрятано {LOTTERY_REWARD} PaketCoin 💰</i>",
        parse_mode=ParseMode.HTML,
        disable_web_page_preview=True,
        reply_markup=lottery_keyboard(user_id, winning)
    )

    await db.close()


@router.callback_query(F.data.startswith("lottery:"))
async def lottery_choice(callback: CallbackQuery):
    await db.connect()
    user_id = callback.from_user.id
    username = callback.from_user.username
    first_name = callback.from_user.first_name
    name_link = f"<a href='https://t.me/{username}'>{first_name}</a>"

    try:
        _, owner_id_str, winning_str, chosen_str = callback.data.split(":")
        owner_id = int(owner_id_str)
        winning = int(winning_str)
        chosen = int(chosen_str)
    except Exception:
        await callback.answer("⚠️ Неверные данные кнопки", show_alert=True)
        await db.close()
        return

    if user_id != owner_id:
        await callback.answer("⛔ Это не твоя лотерея!", show_alert=True)
        await db.close()
        return

    cursor = await db._conn.execute(
        "SELECT claimed_at FROM bonus_claims WHERE user_id = ? AND type = 'daily'",
        (user_id,)
    )
    row = await cursor.fetchone()
    await cursor.close()

    now = datetime.now()
    if row:
        last_time = datetime.fromisoformat(row[0])
        if last_time.date() == now.date():
            await callback.answer("⛔ Ты уже открывал сундук сегодня!", show_alert=True)
            await db.close()
            return

    if chosen == winning:
        await add_kazna_balance(db._conn, -int(LOTTERY_REWARD))
        await db._conn.execute(
            "UPDATE users SET balance = balance + ? WHERE user_id = ?",
            (LOTTERY_REWARD, user_id)
        )
        
        await callback.message.edit_text(
            f"🎉 <i>{name_link}, поздравляем! Ты открыл правильный сундук и получил {LOTTERY_REWARD} PaketCoin!</i>",
            parse_mode=ParseMode.HTML,
            disable_web_page_preview=True
        )
    else:
        await callback.message.edit_text(
            f"😢 <i>{name_link}, увы, этот сундук пуст. Попробуй снова завтра!</i>",
            parse_mode=ParseMode.HTML,
            disable_web_page_preview=True
        )

    await db._conn.execute(
        """
        INSERT INTO bonus_claims (user_id, type, claimed_at)
        VALUES (?, 'daily', CURRENT_TIMESTAMP)
        ON CONFLICT(user_id, type) DO UPDATE SET claimed_at = CURRENT_TIMESTAMP
        """,
        (user_id,)
    )

    await db._conn.commit()
    await callback.answer()
    await db.close()


def format_balance_short(amount: int) -> str:
    if amount >= 1_000_000_000:
        val = amount / 1_000_000_000
        suffix = "kkk"
    elif amount >= 1_000_000:
        val = amount / 1_000_000
        suffix = "kk"
    elif amount >= 1_000:
        val = amount / 1_000
        suffix = "k"
    else:
        return f"{amount:,}".replace(",", "'")

    val_str = f"{val:.2f}".rstrip('0').rstrip('.')
    return f"{val_str}{suffix}"

def parse_amount_with_suffix(value: str) -> int | None:
    match = re.fullmatch(r"(\d+)(к+)", value.lower())
    if match:
        num = int(match.group(1))
        k_count = len(match.group(2))
        multiplier = 1000 ** k_count
        return num * multiplier
    if value.isdigit():
        return int(value)
    return None

def parse_amount_with_suffix(amount_str: str) -> int | None:
    amount_str = amount_str.lower().strip()
    pattern = r'^(\d+(?:[\.,]\d+)?)(к{0,3})$'
    match = re.match(pattern, amount_str)
    if not match:
        return None
    
    number_part = match.group(1).replace(',', '.')
    suffix = match.group(2)
    
    try:
        number = float(number_part)
    except ValueError:
        return None
    
    multiplier = 1
    if suffix == 'к':
        multiplier = 1_000
    elif suffix == 'кк':
        multiplier = 1_000_000
    elif suffix == 'ккк':
        multiplier = 1_000_000_000
    
    return int(number * multiplier)


@router.message(Command("give"))
async def give_handler(message: Message):
    await process_give(message)


@router.message(F.text.regexp(r"^(передать|Передать|п|П)\s+(\d+|все|[\dкКккКкк]+)$", flags=re.IGNORECASE).as_("match"))
async def give_alias_handler(message: Message, match: re.Match[str]):
    amount_str = match.group(2).lower()
    if amount_str != "все" and parse_amount_with_suffix(amount_str) is None:
        await message.answer(
            "❗️ Укажи корректную сумму или 'все'. Пример: <code>Передать 100</code>, <code>Передать 1кк</code> или <code>Передать все</code>",
            parse_mode=ParseMode.HTML,
            disable_web_page_preview=True
        )
        return
    await process_give(message, amount_str)


async def process_give(message: Message, amount_str: str = None):
    user = message.from_user
    sender_id = user.id
    sender_username = user.username or "unknown"
    sender_first_name = user.first_name
    sender_link = f"<a href='https://t.me/{sender_username}'>{sender_first_name}</a>"

    await db.connect()

    if message.chat.type not in ("group", "supergroup"):
        await message.answer(
            "<i>❗️Эта команда работает только в чате с ботом!</i>",
            reply_markup=invite_bot_keyboard(),
            parse_mode=ParseMode.HTML,
            disable_web_page_preview=True
        )
        await db.close()
        return

    if not message.reply_to_message:
        await message.answer(
            "❗️ Чтобы перевести, нужно ответить на сообщение пользователя, которому хотите отправить средства.",
            parse_mode=ParseMode.HTML,
            disable_web_page_preview=True
        )
        await db.close()
        return

    recipient = message.reply_to_message.from_user
    recipient_id = recipient.id
    recipient_username = recipient.username or "unknown"
    recipient_name = recipient.first_name
    recipient_link = f"<a href='https://t.me/{recipient_username}'>{recipient_name}</a>"

    if sender_id == recipient_id:
        await message.answer(
            "❗️<i> Чтобы перевести средства, ответьте на сообщение другого пользователя.</i>",
            parse_mode=ParseMode.HTML,
            disable_web_page_preview=True
        )
        await db.close()
        return

    if amount_str is None:
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.answer(
                f"🤖<i> {sender_link}, ты не ввел корректную сумму для перевода.\nКомиссия на перевод — 10%</i>",
                parse_mode=ParseMode.HTML,
                disable_web_page_preview=True
            )
            await db.close()
            return
        amount_str = args[1].lower()

    async with db._conn.execute("SELECT balance FROM users WHERE user_id = ?", (sender_id,)) as cursor:
        sender_row = await cursor.fetchone()
    if not sender_row:
        await message.answer(
            f"🤖<i> {sender_link}, у тебя нет баланса для перевода.</i>",
            parse_mode=ParseMode.HTML,
            disable_web_page_preview=True
        )
        await db.close()
        return

    async with db._conn.execute("SELECT 1 FROM users WHERE user_id = ?", (recipient_id,)) as cursor:
        recipient_row = await cursor.fetchone()
    if not recipient_row:
        await message.answer(
            "🥲<i> Этого пользователя нет в базе данных.</i>",
            parse_mode=ParseMode.HTML,
            disable_web_page_preview=True
        )
        await db.close()
        return

    sender_balance = sender_row[0]

    if amount_str == "все":
        amount = sender_balance
    else:
        amount = parse_amount_with_suffix(amount_str)
        if amount is None:
            await message.answer(
                f"🤖<i> {sender_link}, ты не ввел корректную сумму для перевода.\n"
                f"Поддерживаются сокращения: 1к, 5кк, 2ккк и т.д.</i>",
                parse_mode=ParseMode.HTML,
                disable_web_page_preview=True
            )
            await db.close()
            return

    if amount <= 0:
        await message.answer(
            f"🤖<i> {sender_link}, сумма должна быть положительной!</i>",
            parse_mode=ParseMode.HTML,
            disable_web_page_preview=True
        )
        await db.close()
        return

    commission = int(amount * 0.10)
    net_amount = amount - commission
    total_deduction = amount

    if sender_balance < total_deduction:
        await message.answer(
            "❗️<i>Недостаточно средств для перевода с комиссией.</i>",
            parse_mode=ParseMode.HTML,
            disable_web_page_preview=True
        )
        await db.close()
        return

    await add_kazna_balance(db._conn, commission)

    await db._conn.execute("UPDATE users SET balance = balance - ? WHERE user_id = ?", (total_deduction, sender_id))
    await db._conn.execute("UPDATE users SET balance = balance + ? WHERE user_id = ?", (net_amount, recipient_id))

    sent_at = datetime.utcnow().isoformat()
    await db._conn.execute(
        """
        INSERT INTO transfers (from_user_id, to_user_id, amount, fee, sent_at)
        VALUES (?, ?, ?, ?, ?)
        """,
        (sender_id, recipient_id, net_amount, commission, sent_at)
    )

    await db._conn.commit()

    balance_str = f"{sender_balance - total_deduction:,}".replace(",", "'")
    amount_str_formatted = f"{net_amount:,}".replace(",", "'")

    transfer_text = (
        f"➡️ <i>{sender_link}, ты передал <b>{amount_str_formatted}</b> PaketCoin {recipient_link}</i>\n"
        f"<code>·····················</code>\n"
        f"🏦<i>Комиссия: <b>{commission}</b> PaketCoin (10%)</i>\n"
        f"💰<i>Баланс: <b>{balance_str}</b> PaketCoin</i>"
    )

    await message.answer(transfer_text, parse_mode=ParseMode.HTML, disable_web_page_preview=True)
    await db.close()


@router.message(or_f(Command("top"), F.text.casefold() == "топ"))
async def top_command(message: Message):
    user_id = message.from_user.id
    await db.connect()

    rows = await db._conn.execute("SELECT user_id, balance FROM users ORDER BY balance DESC LIMIT 10")
    rows = await rows.fetchall()

    pos_row = await db._conn.execute(
        "SELECT COUNT(*) + 1 FROM users WHERE balance > (SELECT balance FROM users WHERE user_id = ?)",
        (user_id,)
    )
    position = (await pos_row.fetchone())[0]
    user_balance_row = await db._conn.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
    user_balance = (await user_balance_row.fetchone())[0] if user_balance_row else 0

    emojis = ["🥇", "🥈", "🥉"]

    text = "<b>🏆 Мировой Топ по PaketCoin</b>\n\n"
    for i, row in enumerate(rows, start=1):
        user_id_in_row = row[0]
        balance_value = row[1]
        try:
            user = await message.bot.get_chat(user_id_in_row)
            username = escape(user.first_name or user.username or "—")
            user_link = f"<a href='tg://user?id={user_id_in_row}'>{username}</a>"
        except Exception:
            user_link = f"<a href='tg://user?id=0'>—</a>"

        emoji = emojis[i-1] if i <= 3 else "🏅"
        balance_str = format_balance_short(balance_value)
        text += f"{i}. {emoji} {user_link} | <code>{balance_str} PaketCoin</code>\n"

    text += "\n<code>·······························</code>\n"
    user_link_self = f"<a href='tg://user?id={user_id}'>{escape('Ты')}</a>"
    user_balance_str = format_balance_short(user_balance)
    text += f"{position}. 🎖 {user_link_self} | <code>{user_balance_str} PaketCoin</code>"

    await message.answer(text, reply_markup=top_main_keyboard(user_id), parse_mode=ParseMode.HTML)
    await db.close()

@router.callback_query(F.data.startswith("top:mcoin:"))
async def mcoin_top_callback(callback: CallbackQuery):
    _, _, _, user_id_str = callback.data.split(":")
    user_id = int(user_id_str)
    await db.connect()

    rows = await db._conn.execute("SELECT user_id, balance FROM users ORDER BY balance DESC LIMIT 10")
    rows = await rows.fetchall()

    pos_row = await db._conn.execute(
        "SELECT COUNT(*) + 1 FROM users WHERE balance > (SELECT balance FROM users WHERE user_id = ?)",
        (user_id,)
    )
    position = (await pos_row.fetchone())[0]
    user_balance_row = await db._conn.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
    user_balance = (await user_balance_row.fetchone())[0] if user_balance_row else 0

    emojis = ["🥇", "🥈", "🥉"]

    text = "<b>💰 ТОП 10 по PaketCoin:</b>\n\n"
    for i, row in enumerate(rows, start=1):
        user_id_in_row = row[0]
        balance_value = row[1]
        try:
            user = await callback.bot.get_chat(user_id_in_row)
            username = user.first_name or user.username or "—"
            user_link = f"<a href='tg://user?id={user_id_in_row}'>{username}</a>"
        except Exception:
            user_link = f"<a href='tg://user?id=0'>—</a>"

        emoji = emojis[i-1] if i <= 3 else "🏅"
        balance_str = format_balance_short(balance_value)
        text += f"{i}. {emoji} {user_link} | <code>{balance_str} PaketCoin</code>\n"

    text += "\n<code>·······························</code>\n"
    user_link_self = f"<a href='tg://user?id={user_id}'>Ты</a>"
    user_balance_str = format_balance_short(user_balance)
    text += f"{position}. 🎖 {user_link_self} | <code>{user_balance_str} PaketCoin</code>"

    await callback.message.edit_text(text, reply_markup=top_main_keyboard(user_id), parse_mode=ParseMode.HTML)
    await callback.answer()
    await db.close()

@router.callback_query(F.data.startswith("top:duel:"))
async def duel_top_callback(callback: CallbackQuery):
    _, _, scope, user_id_str = callback.data.split(":")
    user_id = int(user_id_str)

    if scope != "all":
        await callback.answer("Этот фильтр не поддерживается. Показывается топ за всё время.", show_alert=True)
        return

    await db.connect()
    rows = await db._conn.execute(
        "SELECT user_id, duels_won FROM users ORDER BY duels_won DESC LIMIT 10"
    )
    rows = await rows.fetchall()

    emojis = ["🥇", "🥈", "🥉"]

    text = "<b>📆 Мировой топ по дуэлям за всё время:</b>\n\n"
    for i, row in enumerate(rows, start=1):
        user_id_in_row = row[0]
        wins = row[1]
        try:
            user = await callback.bot.get_chat(user_id_in_row)
            username = user.first_name or user.username or "—"
            user_link = f"<a href='tg://user?id={user_id_in_row}'>{username}</a>"
        except Exception:
            user_link = f"<a href='tg://user?id=0'>—</a>"

        emoji = emojis[i-1] if i <= 3 else "🏅"
        text += f"{i}. {emoji} {user_link} — {wins} побед\n"

    await callback.message.edit_text(
        text,
        parse_mode=ParseMode.HTML,
        reply_markup=duel_filter_keyboard(user_id)
    )
    await callback.answer()
    await db.close()


@router.message(or_f(
    Command("profile"),
    F.text.in_(["профиль", "я", "Профиль", "Я"])
))
async def profile_handler(message: Message):
    await db.connect()
    user_id = message.from_user.id

    user = message.from_user
    username = user.username
    user_name = user.first_name or "—"
    name_link = f"<a href='https://t.me/{username}'>{user_name}</a>"

    rows = await db.fetchall("SELECT * FROM users WHERE user_id = ?", (user_id,))
    user = rows[0] if rows else None
    if not user:
        await message.answer("❗️Профиль не найден.")
        await db.close()
        return
    
    # Получаем уровень администратора
    admin_level = await get_admin_level(db, user_id)


    if admin_level == 6:
        status_str = "<b>Владелец</b>"
    elif admin_level and 1 <= admin_level <= 5:
        status_str = "<b>Админ</b>"
    else:
        status_str = "<b>Игрок</b>"

    games_query = """
        SELECT COUNT(*) as games_played
        FROM games
        WHERE user_id = ?
    """
    async with db._conn.execute(games_query, (user_id,)) as cursor:
        games_row = await cursor.fetchone()
        played = games_row["games_played"] if games_row else 0

    wins = user["coins_win"]
    lost = user["coins_lost"]
    balance = user["balance"]
    donatecoin = user["donatecoin"]

    query = """
    SELECT COUNT(*) + 1 AS rank
    FROM users
    WHERE balance > ?
    """
    row = await db.fetchrow(query, (balance,))
    place = row["rank"] if row else "—"

    date = datetime.fromisoformat(user["registered_at"]).strftime("%d-%m-%Y %H:%M")

    text = (
        f"🆔 <i>Профиль: <code>{user_id}</code></i>\n"
        f"<code>·····················</code>\n"
        f"├ 👤 <i>{name_link}</i>\n"
        f"├ ⚡️ <i>Статус: {status_str}</i>\n"
        f"├ 🎮 <i>Сыграно игр: <b>{played}</b></i>\n"
        f"├ 🏆 <i>Место в топе: <b>{place:,}</b></i>\n"
        f"├ 🟢 <i>Выиграно: <b>{wins:,}</b> PaketCoins</i>\n"
        f"├ 📉 <i>Проиграно: <b>{lost:,}</b> PaketCoins</i>\n"
        f"<blockquote>📅 Дата регистрации: {date}</blockquote>\n"
        f"<code>·····················</code>\n"
        f"💰 <i>Баланс: <b>{balance:,}</b> PaketCoins</i>\n"
        f"💎 <i>Баланс: <b>{donatecoin:,}</b> DonateCoins</i>"
    )

    await message.answer(text, parse_mode=ParseMode.HTML, disable_web_page_preview=True)
    await db.close()