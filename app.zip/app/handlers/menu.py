from aiogram import Router, F
from aiogram.filters import Command
from aiogram.enums import ParseMode
from aiogram.types import Message, FSInputFile, ReplyKeyboardRemove
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from database.queries import create_user, get_user_by_id, add_kazna_balance
from database.setup import Database
from config import load_config
from aiogram.fsm.context import FSMContext
from keyboards.start import start_keyboards
from aiogram.fsm.state import State, StatesGroup
import random

class RegisterCaptcha(StatesGroup):
    waiting_for_captcha = State()


router = Router()

config = load_config()
db = Database(config.bot.database)
print("[Log] Router Menu запущен")

BONUS_FOR_REFERRER = 1000

@router.message(Command("start"))
async def cmd_start(message: Message, state: FSMContext):
    await db.connect()
    await db.init_tables()

    user_id = message.from_user.id
    username = message.from_user.username or ""
    text_args = message.text.split()
    ref_id = None

    if len(text_args) > 1 and text_args[1].startswith("ref_"):
        try:
            ref_id_candidate = int(text_args[1][4:])
            if ref_id_candidate != user_id:
                ref_id = ref_id_candidate
        except ValueError:
            ref_id = None

    existing_user = await get_user_by_id(db._conn, user_id)
    if existing_user:
        return await send_start_message(message)

    correct_index = random.randint(0, 3)
    captcha_buttons = [
        InlineKeyboardButton(text=str(i + 1), callback_data=f"captcha_{i}")
        for i in range(4)
    ]
    captcha_markup = InlineKeyboardMarkup(inline_keyboard=[captcha_buttons])

    await state.update_data(captcha_correct=correct_index, ref_id=ref_id, username=username)
    await state.set_state(RegisterCaptcha.waiting_for_captcha)

    await message.answer(
        text=(
            f"<b>🧠 Подтвердите, что вы не бот!</b>\n"
            f"Нажмите цифру <b>{correct_index + 1}</b>:"
        ),
        reply_markup=captcha_markup,
        parse_mode=ParseMode.HTML
    )

@router.callback_query(RegisterCaptcha.waiting_for_captcha)
async def captcha_handler(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    correct_index = data.get("captcha_correct")
    selected_index = int(callback.data.split("_")[1])

    if selected_index == correct_index:
        user_id = callback.from_user.id
        username = data.get("username") or ""
        ref_id = data.get("ref_id")

        await create_user(db._conn, user_id=user_id, username=username, ref_by=ref_id)

        if ref_id:
            await db.execute(
                "INSERT OR IGNORE INTO referrals (user_id, invited) VALUES (?, ?)",
                (ref_id, user_id)
            )
            await add_kazna_balance(db._conn, -BONUS_FOR_REFERRER)
            await db.execute(
                "UPDATE users SET balance = balance + ? WHERE user_id = ?",
                (BONUS_FOR_REFERRER, ref_id)
            )

        await state.clear()
        await callback.message.delete()
        await callback.answer("✅ Успешно!", show_alert=False)

        admin_chat_id = config.bot.admin_chat
        if admin_chat_id:
            username_display = f"@{username}" if username else "(нет username)"
            if ref_id:
                referral_text = f"Пригласил: <code>{ref_id}</code>"
            else:
                referral_text = "Без реферала"

            await callback.bot.send_message(
                admin_chat_id,
                f"🆕 Новый пользователь:\nID: <code>{user_id}</code>\nUsername: {username_display}\n{referral_text}",
                parse_mode=ParseMode.HTML
            )

        await send_start_message(callback.message)
    else:
        await callback.answer("❌ Неверно. Попробуйте снова.", show_alert=True)

async def send_start_message(message: Message):
    photo = FSInputFile("app/resources/images/start.jpg")
    text = (
        "<b>Привет</b> 👋 Я PaketBet 👾\n\n"
        "💥 <i>Скоротай время с PaketBet и получай выгоду, прокачивая свой канал и чат. "
        "Играй один, с друзьями или всей семьёй — развлечения на любой вкус!</i> ⚡️\n\n"
        "🤔 <i>Итак, во что будем играть сегодня? Просто напиши /game, и начинай!</i>\n\n"
        "❓ <b>Остались вопросы —</b> 👉 /help 😏"
    )

    await message.answer_photo(
        photo=photo,
        caption=text,
        reply_markup=start_keyboards(),
        parse_mode=ParseMode.HTML
    )

    await db.close()
@router.message(Command("game"))
async def play_menu(message: Message):
    user = message.from_user
    username = user.username
    first_name = user.first_name
    name_link = (
        f"<a href='https://t.me/{username}'>{first_name}</a>"
    )

    text = (
        f"<b>🤯 {name_link}, здесь ты можешь поиграть в разные игры!</b>\n"
        "<code>·····················</code>\n"
        "❓ <i>Как запустить игру</i> 👇\n\n"
        "🎰 /casino [ставка]\n"
        "🎲 /dice [ставка] [1-6]\n"
        "📈 /crash [ставка] [1.01-10]\n"
        "🎳 /bowling [ставка]\n"
        "🏀 /basketball [ставка]\n"
        "🎯 /darts [ставка]\n"
        "⚽️ /football [ставка]\n\n"
        "Пример: <code>/casino 100</code>\n"
        "Пример: <code>/dice 100 6</code>\n"
        "Пример: <code>футбол 100</code>"
    )

    await message.answer(
        text,
        parse_mode="HTML",
        disable_web_page_preview=True
    )

@router.message(Command("help"))
async def help_menu(message: Message):
    user = message.from_user
    username = user.username
    first_name = user.first_name
    name_link = (
        f"<a href='https://t.me/{username}'>{first_name}</a>"
    )
    text = (
        f"<i>❓Привет, {name_link} 👾! Здесь собраны все команды, которые тебе могут понадобиться...</i>\n\n"
        "/balance — баланс PaketCoin\n"
        "/bonus — бонусные PaketCoin\n"
        "/give — передать PaketCoin\n"
        "/top — топ по PaketCoin\n"
        "/ref — реферальная ссылка\n"
        "/game — игры\n"
        "/case — кейсы\n"
        "/lottery — лотерея\n"
        "/daily — ежедневный бонус\n"
        "/rp — рп команды\n"
        "/donation — купить DonateCoins\n"
        "/exchange — обменник\n"
        "<code>·····················</code>\n"
    )

    await message.answer(text, parse_mode=ParseMode.HTML, disable_web_page_preview=True, reply_markup=start_keyboards())





    
