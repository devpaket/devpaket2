from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.enums.parse_mode import ParseMode
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from database.setup import Database
from config import load_config
import re
import asyncio
import random

router = Router()
config = load_config()
db = Database(config.bot.database)
print("[Log] Router Job запущен")

class JobStates(StatesGroup):
    selecting_job = State()
    taxi_confirm = State()
    searching_client = State()
    order_accepted = State()
    started_engine = State()
    driving_to_client = State()
    driving_to_destination = State()

def job_menu_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🚕 Такси", callback_data="job_taxi")],
        [InlineKeyboardButton(text="⛰ Шахтер", callback_data="job_miner")]
    ])

def taxi_confirm_keyboard(user_id: int):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Устроиться", callback_data=f"taxi_apply:{user_id}")],
        [InlineKeyboardButton(text="⬅️ Назад", callback_data="job_menu")]
    ])

def search_client_keyboard(user_id: int):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔍 Поиск клиента", callback_data=f"taxi_search:{user_id}")]
    ])

def order_keyboard(user_id: int, reward: int):
    streets = [
        "ул. Пушкина д. 2",
        "пр. Ленина д. 15",
        "ул. Гагарина д. 9",
        "ул. Советская д. 32",
        "ул. Мира д. 44",
        "ул. Победы д. 3"
    ]
    street = random.choice(streets)
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"📍 {street} ({reward} PC)", callback_data=f"taxi_order:{user_id}:{reward}")]
    ])

def start_engine_keyboard(user_id: int):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔧 Завестись", callback_data=f"taxi_start_engine:{user_id}")]
    ])

def drive_to_client_keyboard(user_id: int):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🚗 Поехать", callback_data=f"taxi_drive_client:{user_id}")]
    ])

def drive_to_destination_keyboard(user_id: int):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🏁 Поехать на точку назначения", callback_data=f"taxi_drive_destination:{user_id}")]
    ])

@router.message(F.text.regexp(r"^(работа|Работа|/job)$", flags=re.IGNORECASE))
async def job_command(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(
        "Приветик уважаемый друг, решил подзаработать PaketCoins? Тогда тебе ко мне, пользуйся кнопками ниже.",
        parse_mode=ParseMode.HTML,
        reply_markup=job_menu_keyboard()
    )

@router.callback_query(F.data == "job_menu")
async def job_menu_callback(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.edit_text(
        "Приветик уважаемый друг, решил подзаработать PaketCoins? Тогда тебе ко мне, пользуйся кнопками ниже.",
        parse_mode=ParseMode.HTML,
        reply_markup=job_menu_keyboard()
    )
    await callback.answer()

@router.callback_query(F.data == "job_miner")
async def miner_job_callback(callback: CallbackQuery):
    await callback.message.edit_text(
        "⛰ Работа 'Шахтер' находится в разработке.",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="⬅️ Назад", callback_data="job_menu")]
        ])
    )
    await callback.answer()

@router.callback_query(F.data == "job_taxi")
async def taxi_job_callback(callback: CallbackQuery, state: FSMContext):
    user_id = callback.from_user.id
    await state.update_data(user_id=user_id)
    await callback.message.edit_text(
        "Здравствуй друг мой, если ты хочешь устроиться на работу 'Такси' и развозить клиентов, то тебе сюда, пользуйся кнопкой 'Устроиться'.",
        parse_mode=ParseMode.HTML,
        reply_markup=taxi_confirm_keyboard(user_id)
    )
    await state.set_state(JobStates.taxi_confirm)
    await callback.answer()

@router.callback_query(F.data.startswith("taxi_apply:"))
async def taxi_apply_callback(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    user_id = data.get("user_id")
    if callback.from_user.id != user_id:
        await callback.answer("⛔ Это не твоя работа!", show_alert=True)
        return
    await db.connect()
    await db.execute("UPDATE users SET job = ? WHERE user_id = ?", ("taxi", user_id))
    await db.commit()
    await db.close()
    await callback.message.edit_text(
        "Вы устроились на работу такси, чтобы начать поиск заказов нажмите кнопку ниже.",
        parse_mode=ParseMode.HTML,
        reply_markup=search_client_keyboard(user_id)
    )
    await state.set_state(JobStates.searching_client)
    await callback.answer()

@router.callback_query(F.data.startswith("taxi_search:"))
async def taxi_search_callback(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    user_id = data.get("user_id")
    if callback.from_user.id != user_id:
        await callback.answer("⛔ Это не твоя работа!", show_alert=True)
        return

    await callback.answer()  # Ответить сразу, чтобы не было ошибки

    await callback.message.edit_text("Поиск клиентов начат, ожидайте примерно 3 минуты", parse_mode=ParseMode.HTML)
    await asyncio.sleep(random.randint(60, 180))

    reward = random.randint(500, 1500)
    await state.update_data(reward=reward)
    await callback.message.delete()
    await callback.message.answer(
        "Заказ найден! Следуйте кнопкам ниже",
        parse_mode=ParseMode.HTML,
        reply_markup=order_keyboard(user_id, reward)
    )
    await state.set_state(JobStates.order_accepted)

@router.callback_query(F.data.startswith("taxi_order:"))
async def taxi_order_callback(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    user_id = data.get("user_id")
    if callback.from_user.id != user_id:
        await callback.answer("⛔ Это не твоя работа!", show_alert=True)
        return
    await callback.answer()
    await callback.message.edit_text("Вы взяли заказ! Едьте за клиентом", parse_mode=ParseMode.HTML, reply_markup=start_engine_keyboard(user_id))
    await state.set_state(JobStates.started_engine)

@router.callback_query(F.data.startswith("taxi_start_engine:"))
async def taxi_start_engine_callback(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    user_id = data.get("user_id")
    if callback.from_user.id != user_id:
        await callback.answer("⛔ Это не твоя работа!", show_alert=True)
        return

    await callback.answer()
    await callback.message.edit_text("Заводим двигатель...", parse_mode=ParseMode.HTML)
    await asyncio.sleep(5)
    await callback.message.edit_text("Вы успешно завелись! Пользуйтесь кнопками ниже", parse_mode=ParseMode.HTML, reply_markup=drive_to_client_keyboard(user_id))
    await state.set_state(JobStates.driving_to_client)

@router.callback_query(F.data.startswith("taxi_drive_client:"))
async def taxi_drive_client_callback(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    user_id = data.get("user_id")
    if callback.from_user.id != user_id:
        await callback.answer("⛔ Это не твоя работа!", show_alert=True)
        return

    await callback.answer()

    total_time = random.randint(10, 20)  # секунды
    progress_bar_length = 10

    for elapsed in range(total_time + 1):
        progress = int((elapsed / total_time) * progress_bar_length)
        progress_bar = "🚗" + "■" * progress + "□" * (progress_bar_length - progress)
        text = (
            f"Вы выехали за клиентом, пожалуйста, подождите...\n\n"
            f"{progress_bar} {elapsed}/{total_time} сек"
        )
        await callback.message.edit_text(text, parse_mode=ParseMode.HTML)
        await asyncio.sleep(1)

    await callback.message.edit_text(
        "Вы успешно забрали клиента, едьте на точку назначения",
        parse_mode=ParseMode.HTML,
        reply_markup=drive_to_destination_keyboard(user_id)
    )
    await state.set_state(JobStates.driving_to_destination)

@router.callback_query(F.data.startswith("taxi_drive_destination:"))
async def taxi_drive_destination_callback(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    user_id = data.get("user_id")
    reward = data.get("reward")
    if callback.from_user.id != user_id:
        await callback.answer("⛔ Это не твоя работа!", show_alert=True)
        return

    await callback.answer()

    total_time = random.randint(10, 20)  # секунды
    progress_bar_length = 10

    for elapsed in range(total_time + 1):
        progress = int((elapsed / total_time) * progress_bar_length)
        progress_bar = "🏁" + "■" * progress + "□" * (progress_bar_length - progress)
        text = (
            f"В пути к месту назначения...\n\n"
            f"{progress_bar} {elapsed}/{total_time} сек"
        )
        await callback.message.edit_text(text, parse_mode=ParseMode.HTML)
        await asyncio.sleep(1)

    await db.connect()
    await db.execute("UPDATE users SET balance = balance + ? WHERE user_id = ?", (reward, user_id))
    await db.execute("UPDATE bank_treasury SET balance = balance - ? WHERE id = 1", (reward,))
    await db.commit()
    await db.close()

    await callback.message.edit_text(
        f"Вы успешно доехали до места назначения! Ваш баланс пополнен на {reward} PaketCoin",
        parse_mode=ParseMode.HTML,
        reply_markup=job_menu_keyboard()
    )
    await state.clear()
