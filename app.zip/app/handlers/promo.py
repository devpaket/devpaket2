from aiogram import Router, F
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from aiogram.filters import Command, or_f
from aiogram.enums.parse_mode import ParseMode
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from datetime import datetime
from utils.admin import get_admin_level

from database.setup import Database
from database.queries import update_user_balance
from config import load_config

router = Router()
config = load_config()
db = Database(config.bot.database)

print("[Log] Router Promo запущен")


class PromoFSM(StatesGroup):
    waiting_code = State()
    waiting_reward = State()
    waiting_usage_limit = State()
    waiting_expiration = State()


class ApplyPromoFSM(StatesGroup):
    waiting_code = State()


def cancel_kb():
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="❌ Отмена", callback_data="cancel_promo")]
        ]
    )


def cancel_apply_kb():
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="❌ Отмена", callback_data="cancel_apply_promo")]
        ]
    )


def format_promo_form(data: dict) -> str:
    code = data.get("code", "—")
    reward = data.get("reward", "—")
    usage_limit = data.get("usage_limit", "—")
    expires_at = data.get("expires_at", "—")
    if expires_at != "—" and expires_at is not None:
        expires_at = expires_at.split("T")[0]

    if isinstance(reward, int) or (isinstance(reward, str) and reward.isdigit()):
        reward_str = f"{int(reward):,}"
    else:
        reward_str = str(reward)

    return (
        f"<b>🎁 PaketBet -> Промокод</b>\n"
        f"<code>·····················</code>\n"
        f"<i>Код: <b><code>{code}</code></b></i>\n"
        f"<i>Награда: <b>{reward_str}</b> PaketCoin</i>\n"
        f"<i>Лимит использования: <b>{usage_limit}</b></i>\n"
        f"<i>Истекает: <b>{expires_at}</b></i>\n"
        f"<code>·····················</code>"
    )


@router.message(Command("createpromo"))
async def start_create_promo(message: Message, state: FSMContext):
    from_user_id = message.from_user.id
    admin_level = await get_admin_level(db, from_user_id)

    if admin_level is None or admin_level < 3:
        await message.answer("❌ У вас нет доступа для создания промокодов.")
        return

    empty_data = {}
    sent = await message.answer(
        format_promo_form(empty_data),
        parse_mode=ParseMode.HTML,
        reply_markup=cancel_kb()
    )
    await state.set_state(PromoFSM.waiting_code)
    await state.update_data(prompt_message_id=sent.message_id, **empty_data)


@router.message(PromoFSM.waiting_code)
async def promo_code_step(message: Message, state: FSMContext):
    await message.delete()
    code = message.text.strip().upper()
    await db.connect()
    exists = await db.fetchone("SELECT 1 FROM promocodes WHERE code = ?", (code,))
    await db.close()
    if exists:
        await message.answer("❌ Промокод уже существует. Введите другой код.")
        return
    await state.update_data(code=code)
    data = await state.get_data()
    prompt_message_id = data["prompt_message_id"]
    await message.bot.edit_message_text(
        chat_id=message.chat.id,
        message_id=prompt_message_id,
        text=format_promo_form(data),
        parse_mode=ParseMode.HTML,
        reply_markup=cancel_kb()
    )
    await state.set_state(PromoFSM.waiting_reward)
    await message.answer("💰 Введите сумму награды (целое число):")


@router.message(PromoFSM.waiting_reward)
async def promo_reward_step(message: Message, state: FSMContext):
    if not message.text.isdigit():
        await message.reply("❌ Введите корректное число.")
        return

    reward = int(message.text)
    from_user_id = message.from_user.id
    admin_level = await get_admin_level(db, from_user_id)

    # Ограничения по уровню администратора
    limits = {
        3: 10_000,
        4: 25_000,
        5: 30_000,
        6: None,
    }

    max_limit = limits.get(admin_level, 0)
    if max_limit is not None and reward > max_limit:
        await message.reply(f"❌ Максимальная сумма награды для вашего уровня ({admin_level}) — {max_limit:,} PaketCoin.")
        return

    await message.delete()
    await state.update_data(reward=reward)
    data = await state.get_data()
    prompt_message_id = data["prompt_message_id"]

    await message.bot.edit_message_text(
        chat_id=message.chat.id,
        message_id=prompt_message_id,
        text=format_promo_form(data),
        parse_mode=ParseMode.HTML,
        reply_markup=cancel_kb()
    )
    await state.set_state(PromoFSM.waiting_usage_limit)
    await message.answer("🔢 Введите лимит использования (целое число):")


@router.message(PromoFSM.waiting_usage_limit)
async def promo_limit_step(message: Message, state: FSMContext):
    if not message.text.isdigit():
        await message.reply("❌ Введите корректное число.")
        return
    await message.delete()
    usage_limit = int(message.text)
    await state.update_data(usage_limit=usage_limit)
    data = await state.get_data()
    prompt_message_id = data["prompt_message_id"]
    await message.bot.edit_message_text(
        chat_id=message.chat.id,
        message_id=prompt_message_id,
        text=format_promo_form(data),
        parse_mode=ParseMode.HTML,
        reply_markup=cancel_kb()
    )
    await state.set_state(PromoFSM.waiting_expiration)
    await message.answer("📅 Введите дату истечения (ГГГГ-ММ-ДД) или 'нет':")


@router.message(PromoFSM.waiting_expiration)
async def promo_expire_step(message: Message, state: FSMContext):
    expires_at_input = message.text.strip()
    if expires_at_input.lower() != "нет":
        try:
            datetime.strptime(expires_at_input, "%Y-%m-%d")
        except ValueError:
            await message.reply("❌ Неверный формат даты. Используйте ГГГГ-ММ-ДД или 'нет'.")
            return
    await message.delete()

    data = await state.get_data()
    code = data["code"].upper()
    reward = data["reward"]
    usage_limit = data["usage_limit"]
    expires_at = None if expires_at_input.lower() == "нет" else expires_at_input

    iso_expires_at = None
    if expires_at is not None:
        iso_expires_at = datetime.strptime(expires_at, "%Y-%m-%d").isoformat()

    await state.update_data(expires_at=expires_at)
    data = await state.get_data()
    prompt_message_id = data["prompt_message_id"]

    await db.connect()
    await db.execute(
        """
        INSERT OR REPLACE INTO promocodes (code, reward, usage_limit, used_count, expires_at)
        VALUES (?, ?, ?, 0, ?)
        """,
        (code, reward, usage_limit, iso_expires_at)
    )
    await db.commit()
    await db.close()
    final_text = (
        f"<b>🎁 PaketBet -> Промокод</b>\n"
        f"<code>·····················</code>\n"
        f"<i>Код: <b>{code}</b></i>\n"
        f"<i>Награда: <b>{reward:,}</b> PaketCoin</i>\n"
        f"<i>Лимит использования: <b>{usage_limit}</b></i>\n"
        f"<i>Истекает: <b>{expires_at or '∞'}</b></i>\n"
        f"<code>·····················</code>\n"
        f"✅ Промокод успешно создан!"
    )

    await message.bot.edit_message_text(
        chat_id=message.chat.id,
        message_id=prompt_message_id,
        text=final_text,
        parse_mode=ParseMode.HTML,
        reply_markup=None
    )

    await state.clear()


@router.callback_query(F.data == "cancel_promo")
async def cancel_promo_callback(call: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    prompt_message_id = data.get("prompt_message_id")
    if prompt_message_id:
        try:
            await call.message.bot.delete_message(chat_id=call.message.chat.id, message_id=prompt_message_id)
        except Exception:
            pass
    await call.message.delete()
    await state.clear()
    await call.answer("Создание промокода отменено.", show_alert=True)


async def apply_promo_by_code(message: Message, code: str):
    await db.connect()
    promo = await db.fetchone("SELECT * FROM promocodes WHERE code = ?", (code,))
    if not promo:
        await db.close()
        await message.answer(
            f"<b>🎁 PaketBet -> Ошибка активации</b>\n"
            f"<code>·····················</code>\n"
            f"<i>Промокод <b>{code}</b> не найден.</i>\n"
            f"<code>·····················</code>",
            parse_mode=ParseMode.HTML
        )
        return

    if promo["expires_at"]:
        try:
            if datetime.utcnow() > datetime.fromisoformat(promo["expires_at"]):
                await db.close()
                await message.answer(
                    f"<b>🎁 PaketBet -> Ошибка активации</b>\n"
                    f"<code>·····················</code>\n"
                    f"<i>Промокод <b>{code}</b> истёк.</i>\n"
                    f"<code>·····················</code>",
                    parse_mode=ParseMode.HTML
                )
                return
        except Exception:
            pass

    if promo["used_count"] >= promo["usage_limit"]:
        await db.close()
        await message.answer(
            f"<b>🎁 PaketBet -> Ошибка активации</b>\n"
            f"<code>·····················</code>\n"
            f"<i>Лимит использования промокода <b>{code}</b> исчерпан.</i>\n"
            f"<code>·····················</code>",
            parse_mode=ParseMode.HTML
        )
        return

    already_claimed = await db.fetchone(
        "SELECT 1 FROM promocode_claims WHERE user_id = ? AND code = ?",
        (message.from_user.id, code)
    )
    if already_claimed:
        await db.close()
        await message.answer(
            f"<b>🎁 PaketBet -> Ошибка активации</b>\n"
            f"<code>·····················</code>\n"
            f"<i>Вы уже активировали промокод <b>{code}</b>.</i>\n"
            f"<code>·····················</code>",
            parse_mode=ParseMode.HTML
        )
        return

    await db.execute("UPDATE promocodes SET used_count = used_count + 1 WHERE code = ?", (code,))
    await db.execute("INSERT INTO promocode_claims (user_id, code) VALUES (?, ?)", (message.from_user.id, code))

    user = await db.fetchone("SELECT balance FROM users WHERE user_id = ?", (message.from_user.id,))
    if not user:
        await db.close()
        await message.answer(
            f"<b>🎁 PaketBet -> Ошибка активации</b>\n"
            f"<code>·····················</code>\n"
            f"<i>Пользователь не найден.</i>\n"
            f"<code>·····················</code>",
            parse_mode=ParseMode.HTML
        )
        return

    current_balance = user["balance"] or 0
    new_balance = current_balance + promo["reward"]

    await update_user_balance(db, message.from_user.id, new_balance)
    await db.commit()
    await db.close()

    await message.answer(
        f"<b>🎁 PaketBet -> Активация промокода</b>\n"
        f"<code>·····················</code>\n"
        f"<i>Промокод <b>{code}</b> активирован!</i>\n"
        f"<i>Вы получили: <b>{promo['reward']:,}</b> PaketCoin</i>\n"
        f"<code>·····················</code>",
        parse_mode=ParseMode.HTML
    )


@router.message(or_f(Command("promo"), F.text.casefold().startswith("промо ")))
async def promo_command_handler(message: Message, state: FSMContext):
    parts = message.text.split(maxsplit=1)
    if len(parts) == 2:
        code = parts[1].strip().upper()
        await apply_promo_by_code(message, code)
    else:
        sent = await message.answer(
            "<b>🎁 PaketPromo -> Активация промокода</b>\n"
            "<code>·····················</code>\n"
            "<i>Введите промокод для активации:</i>\n"
            "<code>·····················</code>",
            parse_mode=ParseMode.HTML,
            reply_markup=cancel_apply_kb()
        )
        await state.set_state(ApplyPromoFSM.waiting_code)
        await state.update_data(apply_prompt_message_id=sent.message_id)


@router.message(ApplyPromoFSM.waiting_code)
async def apply_promo_code_step(message: Message, state: FSMContext):
    code = message.text.strip().upper()
    data = await state.get_data()
    prompt_message_id = data.get("apply_prompt_message_id")

    await db.connect()
    promo = await db.fetchone("SELECT * FROM promocodes WHERE code = ?", (code,))
    if not promo:
        if prompt_message_id:
            try:
                await message.bot.delete_message(chat_id=message.chat.id, message_id=prompt_message_id)
            except Exception:
                pass
        await message.answer(
            f"<b>🎁 PaketBet -> Ошибка активации</b>\n"
            f"<code>·····················</code>\n"
            f"<i>Промокод <b>{code}</b> не найден.</i>\n"
            f"<code>·····················</code>",
            parse_mode=ParseMode.HTML
        )
        await state.clear()
        await db.close()
        return

    if promo["expires_at"]:
        try:
            if datetime.utcnow() > datetime.fromisoformat(promo["expires_at"]):
                if prompt_message_id:
                    try:
                        await message.bot.delete_message(chat_id=message.chat.id, message_id=prompt_message_id)
                    except Exception:
                        pass
                await message.answer(
                    f"<b>🎁 PaketBet -> Ошибка активации</b>\n"
                    f"<code>·····················</code>\n"
                    f"<i>Промокод <b>{code}</b> истёк.</i>\n"
                    f"<code>·····················</code>",
                    parse_mode=ParseMode.HTML
                )
                await state.clear()
                await db.close()
                return
        except Exception:
            pass

    if promo["used_count"] >= promo["usage_limit"]:
        if prompt_message_id:
            try:
                await message.bot.delete_message(chat_id=message.chat.id, message_id=prompt_message_id)
            except Exception:
                pass
        await message.answer(
            f"<b>🎁 PaketBet -> Ошибка активации</b>\n"
            f"<code>·····················</code>\n"
            f"<i>Лимит использования промокода <b>{code}</b> исчерпан.</i>\n"
            f"<code>·····················</code>",
            parse_mode=ParseMode.HTML
        )
        await state.clear()
        await db.close()
        return

    already_claimed = await db.fetchone(
        "SELECT 1 FROM promocode_claims WHERE user_id = ? AND code = ?",
        (message.from_user.id, code)
    )
    if already_claimed:
        if prompt_message_id:
            try:
                await message.bot.delete_message(chat_id=message.chat.id, message_id=prompt_message_id)
            except Exception:
                pass
        await message.answer(
            f"<b>🎁 PaketBet -> Ошибка активации</b>\n"
            f"<code>·····················</code>\n"
            f"<i>Вы уже активировали промокод <b>{code}</b>.</i>\n"
            f"<code>·····················</code>",
            parse_mode=ParseMode.HTML
        )
        await state.clear()
        await db.close()
        return

    await db.execute("UPDATE promocodes SET used_count = used_count + 1 WHERE code = ?", (code,))
    await db.execute("INSERT INTO promocode_claims (user_id, code) VALUES (?, ?)", (message.from_user.id, code))

    user = await db.fetchone("SELECT balance FROM users WHERE user_id = ?", (message.from_user.id,))
    if not user:
        await message.answer(
            f"<b>🎁 PaketBet -> Ошибка активации</b>\n"
            f"<code>·····················</code>\n"
            f"<i>Пользователь не найден.</i>\n"
            f"<code>·····················</code>",
            parse_mode=ParseMode.HTML
        )
        await state.clear()
        await db.close()
        return

    current_balance = user["balance"] or 0
    new_balance = current_balance + promo["reward"]

    await update_user_balance(db, message.from_user.id, new_balance)
    await db.commit()
    await db.close()

    if prompt_message_id:
        try:
            await message.bot.delete_message(chat_id=message.chat.id, message_id=prompt_message_id)
        except Exception:
            pass
    await message.answer(
        f"<b>🎁 PaketBet -> Активация промокода</b>\n"
        f"<code>·····················</code>\n"
        f"<i>Промокод <b>{code}</b> активирован!</i>\n"
        f"<i>Вы получили: <b>{promo['reward']:,}</b> PaketCoin</i>\n"
        f"<code>·····················</code>",
        parse_mode=ParseMode.HTML
    )
    await state.clear()


@router.callback_query(F.data == "cancel_apply_promo")
async def cancel_apply_promo_callback(call: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    prompt_message_id = data.get("apply_prompt_message_id")
    if prompt_message_id:
        try:
            await call.message.bot.delete_message(chat_id=call.message.chat.id, message_id=prompt_message_id)
        except Exception:
            pass
    await call.message.delete()
    await state.clear()
    await call.answer("Активация промокода отменена.", show_alert=True)
