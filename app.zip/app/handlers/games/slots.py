from aiogram import Router, F
from aiogram.types import Message
from aiogram.filters import Command, or_f
from aiogram.enums.parse_mode import ParseMode
from aiogram.enums.dice_emoji import DiceEmoji
import asyncio
from database.queries import get_user, update_user_balance, add_kazna_balance
from database.setup import Database
from config import load_config

router = Router()
config = load_config()
db = Database(config.bot.database)

# Отображение эмодзи для каждого символа
SYMBOL_EMOJIS = {
    "BAR": "BAR",
    "виноград": "🍇",
    "лимон": "🍋",
    "семь": "7️⃣",
}

def get_combo_text(dice_value: int) -> list[str]:
    symbols = ["BAR", "виноград", "лимон", "семь"]
    dice_value -= 1
    return [symbols[(dice_value // (4 ** i)) % 4] for i in range(3)]

def format_combo_emoji(combo: list[str]) -> str:
    return " | ".join(SYMBOL_EMOJIS.get(sym, sym) for sym in combo)

@router.message(
    or_f(
        Command("slots"),
        F.text.casefold().startswith("слоты")
    )
)
async def slots_handler(message: Message):
    args = message.text.split()
    user_id = message.from_user.id

    if len(args) < 2 or len(args) > 3:
        await message.answer(
            f"❄️ Некорректный ввод.\n"
            f"<code>·····················</code>\n"
            f"Использование:\n"
            f"<code>/slots</code> <i>[ставка или 'все'] [кол‑во прокрутов (1‑10)]</i>\n"
            f"Пример: <code>/slots 100 5</code> \n"
            f"<code>слоты все 3</code>",
            parse_mode=ParseMode.HTML
        )
        return

    user = await get_user(db, user_id)
    if not user:
        await message.answer(f"❌ Ты не зарегистрирован /start.", parse_mode=ParseMode.HTML)
        return

    bet_str = args[1].lower()
    count_str = args[2] if len(args) == 3 else "1"  # по умолчанию 1 прокрут

    balance = user["balance"]
    amount = balance if bet_str == "все" else None

    if amount is None:
        try:
            amount = int(bet_str)
            if amount <= 9:
                raise ValueError
        except ValueError:
            await message.answer("⚠️ Ставка должна быть больше 10 или 'все'", parse_mode=ParseMode.HTML)
            return

    # ДОПОЛНИТЕЛЬНАЯ ПРОВЕРКА
    if amount <= 0:
        await message.answer("❌ У вас недостаточно средств для ставки.", parse_mode=ParseMode.HTML)
        return

    if amount is None:
        try:
            amount = int(bet_str)
            if amount <= 0:
                raise ValueError
        except ValueError:
            await message.answer("⚠️ Ставка должна быть положительным числом или 'все'", parse_mode=ParseMode.HTML)
            return

    if amount > balance:
        await message.answer("❌ Недостаточно средств.", parse_mode=ParseMode.HTML)
        return

    try:
        spins = int(count_str)
        if spins < 1 or spins > 10:
            raise ValueError
    except ValueError:
        await message.answer("⚠️ Число прокрутов должно быть от\u00a01 до\u00a010.", parse_mode=ParseMode.HTML)
        return
    
    
    base = amount // spins
    extra = amount - base * spins
    costs = [base + (1 if i < extra else 0) for i in range(spins)]

    await add_kazna_balance(db._conn, int(amount))
    await update_user_balance(db, user_id, balance - amount)

    total_win = 0
    result_messages = []

    for idx, cost in enumerate(costs):
        dice_msg = await message.answer_dice(emoji=DiceEmoji.SLOT_MACHINE)
        await asyncio.sleep(4)
        val = dice_msg.dice.value
        combo = get_combo_text(val)
        joined_combo_emoji = format_combo_emoji(combo)

        won = False
        coeff = 0.0

        a, b, c = combo
        if a == b == c:
            if a == "семь":
                won = True
                coeff = 10.0
            else:
                won = True
                coeff = 4.0
        elif (a == b == "семь") or (b == c == "семь") or (a == c == "семь"):
            won = True
            coeff = 1.5
        elif a == b or b == c or a == c:
            won = True
            coeff = 0.7

        win_amount = int(cost * coeff) if won else 0
        total_win += win_amount

        if win_amount > 0:
            await add_kazna_balance(db._conn, -win_amount)
            new_balance = balance - amount + total_win
            await update_user_balance(db, user_id, new_balance)
            await db.execute(
                "UPDATE users SET coins_win = coins_win + ? WHERE user_id = ?",
                (win_amount, user_id)
            )
            status = "win"
            result_text = (
                f"🎰 {format_user(message)} Прокрут {idx + 1}/{spins} — <b>Выигрыш!</b> 🤑\n"
                f"<code>·····················</code>\n"
                f"<blockquote><b>{joined_combo_emoji}</b></blockquote>\n"
                f"💸 Ставка: {cost} PaketCoin\n"
                f"🎉 Выигрыш: {win_amount} PaketCoin (x{coeff})"
            )
        else:
            await db.execute(
                "UPDATE users SET coins_lost = coins_lost + ? WHERE user_id = ?",
                (cost, user_id)
            )
            status = "lose"
            result_text = (
                f"🎰 {format_user(message)} Прокрут {idx + 1}/{spins} — <b>Проигрыш</b>\n"
                f"<code>·····················</code>\n"
                f"<blockquote><b>{joined_combo_emoji}</b></blockquote>\n"
                f"💸 Ставка: {cost} PaketCoin"
            )

        await db.execute(
            "INSERT INTO games (user_id, game_type, bet, status, result) VALUES (?, ?, ?, ?, ?)",
            (user_id, "slots", cost, status, f"{val}")
        )

        result_msg = await message.answer(result_text, parse_mode=ParseMode.HTML, disable_web_page_preview=True, disable_notification=True)

        await asyncio.sleep(3)
        await result_msg.delete()

        if message.chat.type in ["group", "supergroup", "channel"]:
            await dice_msg.delete()
        result_messages.append((cost, win_amount))

    final_text = (
        f"<b>🎰 {format_user(message)}<i> Игра завершена!</i></b>\n"
        f"<code>·····················</code>\n"
        f"💸<i> Общая ставка: <b>{amount}</b> PaketCoin</i>\n"
        f"🎉 <i>Общий выигрыш: <b>{total_win}</b> PaketCoin</i>\n"
    )

    await message.answer(final_text, parse_mode=ParseMode.HTML, disable_web_page_preview=True, disable_notification=True)

def format_user(message: Message) -> str:
    user = message.from_user
    username = user.username
    first_name = user.first_name or "Пользователь"
    if username:
        return f"<a href='https://t.me/{username}'>{first_name}</a>"
    else:
        return first_name
