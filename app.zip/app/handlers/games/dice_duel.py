from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import Command
from aiogram.enums import ChatType
from aiogram.enums.parse_mode import ParseMode
from database.setup import Database
from database.queries import get_user, update_user_balance, add_kazna_balance, update_user_duel_stats
from config import load_config
from aiogram.filters import or_f
import asyncio

router = Router()
config = load_config()
db = Database(config.bot.database)

DUELS = {}

@router.message(
    or_f(
        Command("duel"),
        F.text.casefold().startswith("дуэль")
    )
)
async def start_dice_game(message: Message, bot: Bot):
    if message.chat.type not in [ChatType.GROUP, ChatType.SUPERGROUP]:
        await message.answer("⛔ Команда доступна только в группах.")
        return

    args = message.text.split()
    if len(args) != 3 or not args[1].isdigit() or not args[2].startswith("@"):
        await message.answer("⚠️ Использование: <code>/duel [ставка] @username</code>", parse_mode=ParseMode.HTML)
        return

    amount = int(args[1])
    target_username = args[2].lstrip("@").lower()

    if amount < 100 or amount > 100_000_000:
        await message.answer("⚠️ Ставка должна быть от 100 до 100.000.000 PaketCoin.", parse_mode=ParseMode.HTML)
        return

    p1 = message.from_user

    p1_data = await get_user(db, p1.id)
    p2_data = await db.fetchone("SELECT * FROM users WHERE LOWER(username) = ?", (target_username,))

    if not p1_data or not p2_data:
        await message.answer("⛔ Оба игрока должны быть зарегистрированы через /start.")
        return

    if p1_data["balance"] < amount or p2_data["balance"] < amount:
        await message.answer("💸 У одного из игроков недостаточно средств для участия.")
        return

    if p1.id == p2_data["user_id"]:
        await message.answer("🤨 Нельзя вызвать самого себя на дуэль.")
        return

    duel_id = f"{p1.id}:{p2_data['user_id']}:{message.message_id}"
    DUELS[duel_id] = {
        "chat_id": message.chat.id,
        "amount": amount,
        "initiator": p1,
        "opponent_id": p2_data["user_id"],
        "opponent_username": p2_data["username"]
    }

    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="✅ Принять", callback_data=f"accept_dice:{duel_id}"),
            InlineKeyboardButton(text="❌ Отказаться", callback_data=f"decline_dice:{duel_id}")
        ]
    ])

    await message.answer(
        f"🎲 <b>{p1.full_name}</b> предложил <b>@{p2_data['username']}</b> сыграть в кости на <b>{amount:,} PaketCoin</b>\n\n",
        parse_mode=ParseMode.HTML,
        reply_markup=keyboard
    )


@router.callback_query(F.data.startswith("accept_dice:"))
async def accept_dice(callback: CallbackQuery, bot: Bot):
    _, duel_id = callback.data.split(":", maxsplit=1)
    duel = DUELS.get(duel_id)

    if not duel or callback.from_user.id != duel["opponent_id"]:
        await callback.answer("⛔ Вы не можете принять этот вызов.", show_alert=True)
        return

    amount = duel["amount"]
    p1 = duel["initiator"]
    p2 = callback.from_user
    chat_id = duel["chat_id"]

    p1_data = await get_user(db, p1.id)
    p2_data = await get_user(db, p2.id)
    if not p1_data or not p2_data or p1_data["balance"] < amount or p2_data["balance"] < amount:
        await callback.message.edit_text("💸 У кого-то из игроков не хватает средств.")
        return

    # Списываем полную ставку с обоих игроков
    await update_user_balance(db, p1.id, p1_data["balance"] - amount)
    await update_user_balance(db, p2.id, p2_data["balance"] - amount)

    await callback.message.edit_text("🎲 Игра началась... бросаем кости!")

    # Первый игрок бросает два кубика
    dice_msg1 = await bot.send_dice(chat_id, emoji="🎲")
    await asyncio.sleep(4)
    dice_msg2 = await bot.send_dice(chat_id, emoji="🎲")
    await asyncio.sleep(4)
    total1 = dice_msg1.dice.value + dice_msg2.dice.value

    msg1 = await bot.send_message(chat_id,
        f"<b>🎲 Игрок 1</b>\n"
        f"<code>·····················</code>\n"
        f"Игрок: <a href='tg://user?id={p1.id}'>{p1.full_name}</a>\n"
        f"Выпало всего: {total1}\n"
        f"<code>·····················</code>",
        parse_mode=ParseMode.HTML,
        disable_web_page_preview=True
    )

    # Второй игрок бросает два кубика
    dice_msg3 = await bot.send_dice(chat_id, emoji="🎲")
    await asyncio.sleep(4)
    dice_msg4 = await bot.send_dice(chat_id, emoji="🎲")
    await asyncio.sleep(4)
    total2 = dice_msg3.dice.value + dice_msg4.dice.value

    msg2 = await bot.send_message(chat_id,
        f"<b>🎲 Игрок 2</b>\n"
        f"<code>·····················</code>\n"
        f"Игрок: <a href='tg://user?id={p2.id}'>{p2.full_name}</a>\n"
        f"Выпало всего: {total2}\n"
        f"<code>·····················</code>",
        parse_mode=ParseMode.HTML,
        disable_web_page_preview=True
    )

    # Подождать 2 секунды, затем удалить промежуточные сообщения
    await asyncio.sleep(2)
    await bot.delete_message(chat_id, msg1.message_id)
    await bot.delete_message(chat_id, msg2.message_id)

    # Расчёт распределения выигрыша
    total_pot = amount * 2
    kazna_share = int(total_pot * 0.05)  # 5%
    winner_share = total_pot - kazna_share  # 95%

    if total1 > total2:
        winner_id = p1.id
        winner_name = p1.full_name
    elif total2 > total1:
        winner_id = p2.id
        winner_name = p2.full_name
    else:
        # Ничья — возвращаем средства
        await bot.send_message(chat_id,
            f"<b>🎲 Итог дуэли</b>\n"
            f"<code>·····················</code>\n"
            f"<a href='tg://user?id={p1.id}'>{p1.full_name}</a>: {total1}\n"
            f"<a href='tg://user?id={p2.id}'>{p2.full_name}</a>: {total2}\n"
            f"<code>·····················</code>\n"
            f"🤝 Ничья! Средства возвращены.",
            parse_mode=ParseMode.HTML,
            disable_web_page_preview=True
        )
        # Возвращаем деньги
        await update_user_balance(db, p1.id, p1_data["balance"])
        await update_user_balance(db, p2.id, p2_data["balance"])
        DUELS.pop(duel_id, None)
        return

    # Добавляем выигрыши и записываем статистику победителя
    winner_data = await get_user(db, winner_id)
    await update_user_balance(db, winner_id, winner_data["balance"] + winner_share)
    await add_kazna_balance(db._conn, kazna_share)
    await update_user_duel_stats(db, winner_id, duels_won=1, duel_wins=1)

    await bot.send_message(chat_id,
        f"<b>🎲 Итог дуэли</b>\n"
        f"<code>·····················</code>\n"
        f"<a href='tg://user?id={p1.id}'>{p1.full_name}</a>: {total1}\n"
        f"<a href='tg://user?id={p2.id}'>{p2.full_name}</a>: {total2}\n"
        f"<code>·····················</code>\n"
        f"🏆 Победил <a href='tg://user?id={winner_id}'>{winner_name}</a> и забрал <b>{winner_share:,} PaketCoin</b>!\n",
        parse_mode=ParseMode.HTML,
        disable_web_page_preview=True
    )

    DUELS.pop(duel_id, None)


@router.callback_query(F.data.startswith("decline_dice:"))
async def decline_dice(callback: CallbackQuery):
    _, duel_id = callback.data.split(":", maxsplit=1)
    duel = DUELS.get(duel_id)

    if not duel or callback.from_user.id != duel["opponent_id"]:
        await callback.answer("⛔ Только вызываемый игрок может отказаться.", show_alert=True)
        return

    await callback.message.edit_text("❌ Игрок отказался от вызова.")
    DUELS.pop(duel_id, None)
