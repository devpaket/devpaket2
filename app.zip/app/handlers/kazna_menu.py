from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import Command
from aiogram.enums.parse_mode import ParseMode
from config import load_config
from database.setup import Database 
from aiogram.filters import CommandObject
from aiogram.filters import or_f
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from utils.admin import get_admin_level

config = load_config()
db = Database(config.bot.database)
router = Router()
print("[Log] Router Kazna запущен")

class TreasuryWithdraw(StatesGroup):
    waiting_for_amount = State()

@router.message(
    or_f(
        Command("kazna"),
        F.text.casefold().startswith("казна")
    )
)
async def show_treasury_balance(message: Message):
    admin_level = await get_admin_level(db, message.from_user.id)
    if not admin_level or admin_level < 6:
        return await message.answer("❌ У вас нет доступа к казне.")

    await db.connect()
    try:
        cursor = await db._conn.execute("SELECT balance FROM bank_treasury WHERE id = 1")
        row = await cursor.fetchone()
        await cursor.close()
        balance = row[0] if row else 0
        formatted_balance = f"{balance:,}".replace(",", ".")

        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="💳 Снять средства", callback_data="withdraw_from_treasury")]
        ])

        await message.answer(
            (
                f"<b>🏛 Казна PaketBet</b>\n"
                f"<code>·····················</code>\n"
                f"<b>💰 Баланс:</b> <code>{formatted_balance} PaketCoin</code>\n"
                f"<code>·····················</code>"
            ),
            parse_mode=ParseMode.HTML,
            reply_markup=keyboard
        )
    finally:
        await db.close()

@router.callback_query(F.data == "withdraw_from_treasury")
async def start_withdraw(callback: CallbackQuery, state: FSMContext):
    admin_level = await get_admin_level(db, callback.from_user.id)
    if not admin_level or admin_level < 6:
        return await callback.answer("⛔️ Нет доступа", show_alert=True)

    await state.set_state(TreasuryWithdraw.waiting_for_amount)
    await callback.message.answer("💳 Введите сумму, которую хотите снять из казны:")
    await callback.answer()

@router.message(TreasuryWithdraw.waiting_for_amount)
async def process_withdraw_amount(message: Message, state: FSMContext):
    user_id = message.from_user.id
    admin_level = await get_admin_level(db, user_id)
    if not admin_level or admin_level < 6:
        await state.clear()
        return await message.answer("❌ У вас нет прав для снятия средств из казны.")

    try:
        amount = int(message.text)
    except ValueError:
        return await message.answer("❗️ Сумма должна быть целым числом.")

    if amount <= 0:
        return await message.answer("❗️ Сумма должна быть положительной.")

    await db.connect()
    try:
        cursor = await db._conn.execute("SELECT balance FROM bank_treasury WHERE id = 1")
        row = await cursor.fetchone()
        await cursor.close()
        current_balance = row[0] if row else 0

        if amount > current_balance:
            return await message.answer(f"❗️ Недостаточно средств в казне. Текущий баланс: {current_balance} PaketCoin")

        await db._conn.execute(
            "UPDATE bank_treasury SET balance = balance - ? WHERE id = 1",
            (amount,)
        )

        await db._conn.execute(
            "UPDATE users SET balance = balance + ? WHERE user_id = ?",
            (amount, user_id)
        )

        await db._conn.commit()
        await state.clear()

        await message.answer(
            f"✅ Успешно снято {amount} PaketCoin из казны и начислено на ваш баланс."
        )

        await message.bot.send_message(
            chat_id=config.bot.admin_chat,
            text=(
                f"📤 <b>Снятие из казны</b>\n"
                f"Админ: <a href=\"tg://user?id={user_id}\">{message.from_user.full_name}</a>\n"
                f"Сумма: <code>{amount} PaketCoin</code>"
            ),
            parse_mode=ParseMode.HTML,
            disable_web_page_preview=True
        )
    finally:
        await db.close()