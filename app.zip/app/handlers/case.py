from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.enums.parse_mode import ParseMode
from aiogram.filters import Command
from database.queries import get_user, update_user_balance, add_kazna_balance
from database.setup import Database
from config import load_config
import random
import json
import uuid

router = Router()
config = load_config()
db = Database(config.bot.database)
cases = [
    {"name": "Кейс бомжа", "emoji": "🗑️", "cost": 100, "max_win": 300, "bonus_chance": 0.1},
    {"name": "Standart Case", "emoji": "📦", "cost": 500, "max_win": 1200, "bonus_chance": 0.15},
    {"name": "Martin Case", "emoji": "🚗", "cost": 1000, "max_win": 2000, "bonus_chance": 0.2},
    {"name": "Vadiqz Case", "emoji": "🎮", "cost": 700, "max_win": 1500, "bonus_chance": 0.18},
    {"name": "Mizzka Case", "emoji": "🐻", "cost": 2200, "max_win": 5000, "bonus_chance": 0.25},
    {"name": "Baton Case", "emoji": "🍞", "cost": 10000, "max_win": 25000, "bonus_chance": 0.3},
    {"name": "DevVolodya Case", "emoji": "💻", "cost": 15000, "max_win": 40000, "bonus_chance": 0.33},
    {"name": "Vip Case", "emoji": "👑", "cost": 25000, "max_win": 60000, "bonus_chance": 0.35},
    {"name": "Deluxe Case", "emoji": "💎", "cost": 50000, "max_win": 111111, "bonus_chance": 0.4},
    {"name": "Paket Case", "emoji": "🏷️", "cost": 1000000, "max_win": 2500000, "bonus_chance": 0.5},
]

def format_user(obj):
    user = obj.from_user
    name = user.first_name or "Игрок"
    return f"<a href='https://t.me/{user.username}'>{name}</a>" if user.username else name

async def get_case_by_name(case_name):
    return next((c for c in cases if c["name"] == case_name), None)

async def create_case_opening(user_id, chat_id, message_id, case_name):
    case = await get_case_by_name(case_name)
    grid = [[0] * 3 for _ in range(3)]
    win_positions = random.sample([(i, j) for i in range(3) for j in range(3)], 6)
    max_val = case["max_win"] // 3
    for i, j in win_positions:
        grid[i][j] = random.randint(1, max_val)
    opening_id = str(uuid.uuid4())
    await db.execute(
        "INSERT INTO case_openings (id, user_id, chat_id, message_id, case_name, grid, opened_slots, total_opened, max_opens, streak) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (opening_id, user_id, chat_id, message_id, case_name, json.dumps(grid), json.dumps([]), 0, 3, 0)
    )
    return opening_id

async def update_streak(user_id, case_name):
    streak = await db.fetchone("SELECT streak FROM user_streaks WHERE user_id = ? AND case_name = ?", (user_id, case_name))
    streak = streak["streak"] + 1 if streak else 1
    await db.execute(
        "INSERT OR REPLACE INTO user_streaks (user_id, case_name, streak) VALUES (?, ?, ?)",
        (user_id, case_name, streak)
    )
    return streak

async def get_bonus(case, streak):
    return int(case["max_win"] * case["bonus_chance"]) if random.random() < case["bonus_chance"] * (1 + streak * 0.1) else 0

@router.message(Command("case"))
async def show_case_menu(message: Message):
    user_id = message.from_user.id
    user = await get_user(db, user_id)
    if not user:
        return
    balance = user["balance"]
    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=f"{case['emoji']} {case['name']} - {case['cost']} PC", callback_data=f"case_select:{case['name']}:{user_id}")]
            for case in cases
        ]
    )
    await message.answer(
        f"🧐 {format_user(message)}, выбери кейс 📦\n"
        f"💰 Баланс: {balance} PaketCoin\n"
        f"<code>═══════════════</code>",
        reply_markup=markup,
        parse_mode=ParseMode.HTML,
        disable_web_page_preview=True
    )

@router.message(Command("case_history"))
async def show_case_history(message: Message):
    user_id = message.from_user.id
    history = await db.fetchall("SELECT case_name, total_opened, grid, opened_slots FROM case_openings WHERE user_id = ? ORDER BY created_at DESC LIMIT 5", (user_id,))
    if not history:
        return await message.answer(f"🧐 {format_user(message)}, у тебя нет открытых кейсов 📭")
    text = f"📜 История кейсов для {format_user(message)}:\n<code>═══════════════</code>\n"
    for entry in history:
        case = await get_case_by_name(entry["case_name"])
        opened = json.loads(entry["opened_slots"])
        grid = json.loads(entry["grid"])
        win = sum(grid[int(p.split(",")[0])][int(p.split(",")[1])] for p in opened)
        text += f"{case['emoji']} {entry['case_name']}: Выигрыш {win} mCoin\n"
    await message.answer(text, parse_mode=ParseMode.HTML)

@router.callback_query(F.data.startswith("case_select:"))
async def select_case(callback: CallbackQuery):
    _, case_name, user_id = callback.data.split(":")
    user_id = int(user_id)
    if callback.from_user.id != user_id:
        return await callback.answer("⛔ Это не твой кейс!", show_alert=True)
    case = await get_case_by_name(case_name)
    if not case:
        return
    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🛒 Купить", callback_data=f"case_buy:{case_name}:{user_id}")],
            [InlineKeyboardButton(text="🔙 Назад", callback_data=f"case_back:{user_id}")]
        ]
    )
    await callback.message.edit_text(
        f"🎯 {format_user(callback)}, кейс: {case['emoji']} {case['name']}\n"
        f"<code>═══════════════</code>\n"
        f"💸 Стоимость: {case['cost']} PaketCoin\n"
        f"🏆 Макс. выигрыш: {case['max_win']} PaketCoin",
        reply_markup=markup,
        parse_mode=ParseMode.HTML,
        disable_web_page_preview=True
    )

@router.callback_query(F.data.startswith("case_back:"))
async def back_to_menu(callback: CallbackQuery):
    _, user_id = callback.data.split(":")
    user_id = int(user_id)
    if callback.from_user.id != user_id:
        return await callback.answer("⛔ Это не твой кейс!", show_alert=True)
    user = await get_user(db, user_id)
    balance = user["balance"]
    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=f"{case['emoji']} {case['name']} - {case['cost']} PC", callback_data=f"case_select:{case['name']}:{user_id}")]
            for case in cases
        ]
    )
    await callback.message.edit_text(
        f"🧐 {format_user(callback)}, выбери кейс 📦\n"
        f"💰 Баланс: {balance} PaketCoin\n"
        f"<code>═══════════════</code>",
        reply_markup=markup,
        parse_mode=ParseMode.HTML
    )

@router.callback_query(F.data.startswith("case_buy:"))
async def buy_case(callback: CallbackQuery):
    _, case_name, user_id = callback.data.split(":")
    user_id = int(user_id)
    if callback.from_user.id != user_id:
        return await callback.answer("⛔ Это не твой кейс!", show_alert=True)
    case = await get_case_by_name(case_name)
    if not case:
        return
    user = await get_user(db, user_id)
    if user["balance"] < case["cost"]:
        return await callback.answer("❌ Недостаточно PaketCoin!", show_alert=True)
    await update_user_balance(db, user_id, user["balance"] - case["cost"])
    await add_kazna_balance(db._conn, case["cost"])
    opening_id = await create_case_opening(user_id, callback.message.chat.id, callback.message.message_id, case_name)
    await update_streak(user_id, case_name)
    await display_case(callback.message, opening_id)

@router.callback_query(F.data.startswith("case_open:"))
async def open_slot(callback: CallbackQuery):
    _, opening_id, row, col, user_id = callback.data.split(":")
    row, col, user_id = int(row), int(col), int(user_id)
    if callback.from_user.id != user_id:
        return await callback.answer("⛔ Это не твой кейс!", show_alert=True)
    opening = await db.fetchone("SELECT * FROM case_openings WHERE id = ?", (opening_id,))
    if not opening or opening["total_opened"] >= opening["max_opens"]:
        return await callback.answer("❌ Все ячейки открыты!", show_alert=True)
    opened = json.loads(opening["opened_slots"])
    pos = f"{row},{col}"
    if pos in opened:
        return await callback.answer("❌ Ячейка уже открыта!", show_alert=True)
    opened.append(pos)
    total_opened = opening["total_opened"] + 1
    await db.execute(
        "UPDATE case_openings SET opened_slots = ?, total_opened = ? WHERE id = ?",
        (json.dumps(opened), total_opened, opening_id)
    )
    await display_case(callback.message, opening_id)

@router.callback_query(F.data.startswith("case_another:"))
async def open_another_case(callback: CallbackQuery):
    _, opening_id, user_id = callback.data.split(":")
    user_id = int(user_id)
    if callback.from_user.id != user_id:
        return await callback.answer("⛔ Это не твой кейс!", show_alert=True)
    old = await db.fetchone("SELECT * FROM case_openings WHERE id = ?", (opening_id,))
    if not old:
        return
    case_name = old["case_name"]
    case = await get_case_by_name(case_name)
    if not case:
        return
    user = await get_user(db, user_id)
    if user["balance"] < case["cost"]:
        return await callback.answer("❌ Недостаточно PaketCoin!", show_alert=True)
    await update_user_balance(db, user_id, user["balance"] - case["cost"])
    await add_kazna_balance(db._conn, case["cost"])
    new_id = await create_case_opening(user_id, callback.message.chat.id, callback.message.message_id, case_name)
    await update_streak(user_id, case_name)
    await display_case(callback.message, new_id)

async def display_case(message: Message, opening_id: str):
    opening = await db.fetchone("SELECT * FROM case_openings WHERE id = ?", (opening_id,))
    if not opening:
        return
    user_id = opening["user_id"]
    case_name = opening["case_name"]
    grid = json.loads(opening["grid"])
    opened = json.loads(opening["opened_slots"])
    total = opening["total_opened"]
    max_opens = opening["max_opens"]
    case = await get_case_by_name(case_name)
    if not case:
        return
    streak = await update_streak(user_id, case_name)
    bonus = await get_bonus(case, streak)
    text = f"🎉 {format_user(message)}, кейс {case['emoji']} {case_name}\n"
    text += f"<code>═══════════════</code>\n"
    text += f"✅ Осталось открыть: {max_opens - total}\n"
    text += f"🔥 Серия открытий: {streak}\n"
    for i in range(min(total, max_opens)):
        row, col = map(int, opened[i].split(","))
        value = grid[row][col]
        text += f"{i+1}⃣ 💰 {value:+d} mCoin\n"
    for i in range(total, max_opens):
        text += f"{i+1}⃣ ◾ - открой ячейку\n"
    if total >= max_opens and bonus:
        text += f"🎁 Бонус: {bonus} mCoin\n"
    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=f"💰 {grid[i][j]}" if f"{i},{j}" in opened else "◾",
                    callback_data=f"case_open:{opening_id}:{i}:{j}:{user_id}"
                ) for j in range(3)
            ] for i in range(3)
        ]
    )
    if total >= max_opens:
        win = sum(grid[int(p.split(",")[0])][int(p.split(",")[1])] for p in opened) + bonus
        user = await get_user(db, user_id)
        await update_user_balance(db, user_id, user["balance"] + win)
        if win:
            await add_kazna_balance(db._conn, -win)
        markup.inline_keyboard.append([InlineKeyboardButton(text="🔄 Еще раз", callback_data=f"case_another:{opening_id}:{user_id}")])
        text += f"🏆 Итоговый выигрыш: {win} mCoin"
    await message.edit_text(text, reply_markup=markup, parse_mode=ParseMode.HTML)