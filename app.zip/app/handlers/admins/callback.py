from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from aiogram.enums.parse_mode import ParseMode
from aiogram.filters import CommandObject
from database.setup import Database
from utils.admin import get_admin_level  # Функция проверки уровня
from config import load_config

router = Router()
config = load_config()
db = Database(config.bot.database)

OWNER_ID = config.bot.admin_chat  # чат админов
BOT_USERNAME = config.bot.bot_username  # добавляем для ссылки на бота

# Хранение открытых тикетов: user_id -> admin_id или None
OPEN_TICKETS = {}

class ReportState(StatesGroup):
    waiting_report = State()

def close_button(ticket_owner_id: int):
    return InlineKeyboardButton(text="❌ Закрыть тикет", callback_data=f"close_ticket:{ticket_owner_id}")

def chat_button():
    url = f"https://t.me/{BOT_USERNAME}"
    return InlineKeyboardButton(text="💬 Перейти в чат", url=url)

def admin_ticket_controls(ticket_owner_id: int):
    # Кнопки "Закрыть" + "Перейти в чат"
    return InlineKeyboardMarkup(inline_keyboard=[
        [close_button(ticket_owner_id), chat_button()]
    ])

def admin_take_button(ticket_owner_id: int):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🛠 Взять тикет", callback_data=f"take_ticket:{ticket_owner_id}")]
    ])

@router.message(Command("report"))
async def report_start(message: Message, state: FSMContext):
    await state.set_state(ReportState.waiting_report)
    await message.answer(
        "<b>📝 Отправьте ваш репорт</b>\n\n"
        "Опишите проблему или вопрос, и наши администраторы свяжутся с вами.",
        parse_mode=ParseMode.HTML
    )

@router.message(ReportState.waiting_report, F.text)
async def report_received(message: Message, state: FSMContext):
    user = message.from_user
    report_text = message.text.strip()

    if user.id in OPEN_TICKETS:
        await message.answer("⚠️ У вас уже есть открытый тикет. Пожалуйста, дождитесь ответа администратора.")
        await state.clear()
        return

    OPEN_TICKETS[user.id] = None

    await message.bot.send_message(
        chat_id=OWNER_ID,
        text=(
            f"<b>📥 Новый репорт</b>\n"
            f"<b>От:</b> <a href='tg://user?id={user.id}'>{user.full_name}</a> (@{user.username if user.username else '—'})\n"
            f"<b>ID:</b> <code>{user.id}</code>\n\n"
            f"<b>Сообщение:</b>\n<pre>{report_text}</pre>"
        ),
        parse_mode=ParseMode.HTML,
        disable_web_page_preview=True,
        reply_markup=admin_take_button(user.id)
    )

    await message.answer("✅ Ваш репорт отправлен в службу поддержки. Ожидайте ответа.")
    await state.clear()

async def is_admin(user_id: int) -> bool:
    level = await get_admin_level(db, user_id)
    return level is not None and 1 <= level <= 6

@router.callback_query(F.data.startswith("take_ticket:"))
async def admin_take_ticket(callback: CallbackQuery, bot: Bot):
    admin_id = callback.from_user.id
    user_id = int(callback.data.split(":")[1])
    admin_level = await get_admin_level(db, admin_id)

    if not admin_level or admin_level < 1 or admin_level > 6:
        return await callback.answer("⛔ У вас нет доступа к взятию тикетов.", show_alert=True)

    if user_id not in OPEN_TICKETS:
        return await callback.answer("⚠️ Этот тикет уже закрыт или не существует.", show_alert=True)

    if OPEN_TICKETS[user_id] is not None:
        return await callback.answer("⚠️ Этот тикет уже взят другим администратором.", show_alert=True)

    OPEN_TICKETS[user_id] = admin_id

    # Убираем кнопку "Взять"
    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.answer("✅ Тикет взят в работу.")

    # Отправляем сообщение в админ-чат с кнопками "Закрыть" и "Перейти в чат"
    await bot.send_message(
        chat_id=OWNER_ID,
        text=(
            f"🛠 Тикет <code>{user_id}</code> взят администратором "
            f"<a href='tg://user?id={admin_id}'>{callback.from_user.full_name}</a>.\n\n"
            f"💬 Для общения с пользователем используйте бота."
        ),
        parse_mode=ParseMode.HTML,
        disable_web_page_preview=True,
        reply_markup=admin_ticket_controls(user_id)
    )

    # Уведомляем пользователя
    await bot.send_message(
        chat_id=user_id,
        text=(
            f"🛠 Ваш репорт взял в работу администратор "
            f"<a href='tg://user?id={admin_id}'>{callback.from_user.full_name}</a>. "
            "Вы можете продолжить писать сообщения сюда, и они будут передаваться администратору."
        ),
        parse_mode=ParseMode.HTML,
        disable_web_page_preview=True
    )

@router.message()
async def forward_user_message(message: Message):
    user_id = message.from_user.id
    if user_id in OPEN_TICKETS and OPEN_TICKETS[user_id] is not None:
        if await is_admin(user_id):
            return
        admin_id = OPEN_TICKETS[user_id]
        try:
            await message.bot.send_message(
                chat_id=admin_id,
                text=(
                    f"📨 <b>Сообщение от пользователя</b>\n"
                    f"<a href='tg://user?id={user_id}'>{message.from_user.full_name}</a>:\n"
                    f"{message.text}"
                ),
                parse_mode=ParseMode.HTML,
                disable_web_page_preview=True
            )
        except Exception:
            pass

@router.message()
async def forward_admin_message(message: Message):
    admin_id = message.from_user.id
    if await is_admin(admin_id) and admin_id in OPEN_TICKETS.values():
        user_id = None
        for uid, aid in OPEN_TICKETS.items():
            if aid == admin_id:
                user_id = uid
                break
        if user_id:
            try:
                # Отправляем сообщение пользователю
                await message.bot.send_message(
                    chat_id=user_id,
                    text=(
                        f"📨 <b>Ответ от администратора</b>\n"
                        f"{message.text}"
                    ),
                    parse_mode=ParseMode.HTML,
                    disable_web_page_preview=True
                )
                # Удаляем сообщение администратора
                await message.delete()

                # Отправляем подтверждение администратору с кнопкой "Закрыть тикет"
                await message.answer(
                    "✅ Вы успешно отправили сообщение пользователю.",
                    reply_markup=admin_ticket_controls(user_id)
                )

            except Exception:
                pass

@router.callback_query(F.data.startswith("close_ticket:"))
async def close_ticket(callback: CallbackQuery, bot: Bot):
    admin_id = callback.from_user.id
    user_id = int(callback.data.split(":")[1])
    admin_level = await get_admin_level(db, admin_id)

    if not admin_level or admin_level < 1 or admin_level > 6:
        return await callback.answer("⛔ У вас нет доступа.", show_alert=True)

    # Проверяем, взял ли тикет админ, либо админ 5+ уровня (может закрывать чужие)
    if user_id not in OPEN_TICKETS:
        return await callback.answer("⚠️ Тикет уже закрыт или не найден.", show_alert=True)

    ticket_admin_id = OPEN_TICKETS[user_id]
    if ticket_admin_id != admin_id and admin_level < 5:
        return await callback.answer("⚠️ Вы не можете закрыть чужой тикет.", show_alert=True)

    OPEN_TICKETS.pop(user_id)

    await callback.message.edit_text(f"✅ Тикет пользователя <code>{user_id}</code> закрыт.", parse_mode=ParseMode.HTML)

    try:
        await bot.send_message(
            chat_id=user_id,
            text="✅ Ваш тикет закрыт администратором. Спасибо за обращение!"
        )
    except Exception:
        pass

    # Логирование в БД: увеличение счетчика закрытых тикетов
    await db.connect()
    try:
        await db._conn.execute(
            "UPDATE admins SET tickets_closed = tickets_closed + 1 WHERE admin_id = ?",
            (admin_id,)
        )
        await db._conn.commit()
    finally:
        await db.close()

    # Логирование в админ-чат
    await bot.send_message(
        chat_id=OWNER_ID,
        text=(
            f"❌ Тикет пользователя <code>{user_id}</code> закрыт "
            f"администратором <a href='tg://user?id={admin_id}'>{callback.from_user.full_name}</a>."
        ),
        parse_mode=ParseMode.HTML,
        disable_web_page_preview=True
    )

@router.message(Command("close_ticket"))
async def close_ticket_command(message: Message, command: CommandObject):
    admin_id = message.from_user.id
    admin_level = await get_admin_level(db, admin_id)

    if not admin_level or admin_level < 5:
        return await message.answer("❌ У вас нет прав для принудительного закрытия тикетов.")

    args = command.args
    if not args or not args.isdigit():
        return await message.answer("❗ Использование: /close_ticket <UserID>")

    user_id = int(args)

    if user_id not in OPEN_TICKETS:
        return await message.answer("⚠️ Тикет пользователя не найден или уже закрыт.")

    OPEN_TICKETS.pop(user_id)

    await message.answer(f"✅ Тикет пользователя <code>{user_id}</code> закрыт принудительно.", parse_mode=ParseMode.HTML)

    try:
        await message.bot.send_message(
            chat_id=user_id,
            text="✅ Ваш тикет был закрыт администрацией. Если нужно, создайте новый."
        )
    except Exception:
        pass

    # Логирование закрытия в БД
    await db.connect()
    try:
        await db._conn.execute(
            "UPDATE admins SET tickets_closed = tickets_closed + 1 WHERE admin_id = ?",
            (admin_id,)
        )
        await db._conn.commit()
    finally:
        await db.close()

    # Логирование в админ-чат
    await message.bot.send_message(
        chat_id=OWNER_ID,
        text=(
            f"❌ Тикет пользователя <code>{user_id}</code> был закрыт принудительно "
            f"администратором <a href='tg://user?id={admin_id}'>{message.from_user.full_name}</a>."
        ),
        parse_mode=ParseMode.HTML,
        disable_web_page_preview=True
    )
