from aiogram import Router, F
from aiogram.filters import or_f, Command
from aiogram.types import Message, CallbackQuery, ContentType, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.enums.parse_mode import ParseMode
from aiogram.fsm.context import FSMContext
from datetime import datetime, timedelta
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove
from aiogram.fsm.context import FSMContext
from database.queries import (
    get_user, get_bank_account, get_bonus_claims,
    get_referrals, get_games_stats, set_user_ban_status, delete_user_account, add_kazna_balance
)
from database.setup import Database
from utils.admin import is_admin, get_admin_level, get_role_name_by_level
from config import load_config
from aiogram.fsm.state import State, StatesGroup
import asyncio
import locale


class SendBroadcastState(StatesGroup):
    waiting_for_text = State()
    waiting_for_media = State()
    waiting_for_confirm = State()


class SetAdminState(StatesGroup):
    waiting_for_user_id = State()
    waiting_for_role = State()
    waiting_for_level = State()

class GiveState(StatesGroup):
    user_id = State()
    currency = State()
    amount = State()

config = load_config()
db = Database(config.bot.database)
router = Router()
print("[Log] Router AdminPanel запущен")


def format_user_info(user, bank_account, bonus_claims, referrals, stats, admin_level):
    def fmt_num(value): 
        return f"{int(value):,}".replace(",", " ") if isinstance(value, (int, float)) else "—"
    def fmt_date(value): 
        return value or "—"

    role_text = get_role_name_by_level(admin_level)
    banned_text = "✅ Заблокирован" if user.get("is_banned") else "❌ Не заблокирован"

    text = (
        f"<b>👤 Информация о пользователе</b>\n"
        f"ID: <code>{user['user_id']}</code>\n"
        f"Username: <b>@{user.get('username') or '—'}</b>\n"
        f"Баланс: <code>{fmt_num(user.get('balance'))}</code> PaketCoin\n"
        f"DonateCoin: <code>{fmt_num(user.get('donatecoin'))}</code>\n"
        f"{banned_text}\n"
        f"Роль: {role_text}\n"
        f"Дата регистрации: <i>{fmt_date(user.get('registered_at'))}</i>\n\n"

        f"<b>🏦 Банковский счёт</b>\n"
        f"Баланс: <code>{fmt_num(bank_account.get('balance')) if bank_account else '—'}</code>\n"
        f"Активный депозит: <code>{fmt_num(bank_account.get('deposit')) if bank_account else '—'}</code>\n"
    )

    if bank_account and bank_account.get('deposit'):
        text += (
            f"Дата начала: <i>{fmt_date(bank_account.get('deposit_start'))}</i>\n"
            f"Процент: <code>{bank_account.get('procent')}%</code>\n\n"
        )
    else:
        text += "\n"

    text += (
        f"<b>🎁 Бонусы</b>\n"
        f"Записей: <code>{len(bonus_claims) if bonus_claims else 0}</code>\n\n"

        f"<b>👥 Рефералы</b>\n"
        f"Всего: <code>{len(referrals) if referrals else 0}</code>\n\n"
    )


    return text

@router.message(or_f(Command("info"), F.text.casefold().startswith("инфо")))
async def info_handler(message: Message):
    admin_id = message.from_user.id
    if not await is_admin(db, admin_id):
        return await message.answer("❌ У вас нет прав.")

    target_user_id = message.reply_to_message.from_user.id if message.reply_to_message else None
    if not target_user_id:
        parts = message.text.split()
        if len(parts) == 2 and parts[1].isdigit():
            target_user_id = int(parts[1])
        else:
            target_user_id = admin_id

    user = await get_user(db, target_user_id)
    if not user:
        return await message.answer("❌ Пользователь не найден.")
    user = dict(user)

    bank = await get_bank_account(db, target_user_id) or {}
    bonus = await get_bonus_claims(db, target_user_id) or []
    refs = await get_referrals(db, target_user_id) or []
    stats = await get_games_stats(db, target_user_id) or {}
    user["admin_level"] = await get_admin_level(db, target_user_id) or 0

    admin_level = await get_admin_level(db, admin_id) or 0

    text = format_user_info(user, bank, bonus, refs, stats, user["admin_level"])
    await message.answer(text=text, parse_mode=ParseMode.HTML)



@router.message(Command("setaccess"))
async def setaccess_handler(message: Message):
    if message.from_user.id != int(config.bot.owner_id):
        return await message.answer("❌ Только владелец может использовать эту команду.")

    await db.execute(
        "INSERT OR REPLACE INTO admins (user_id, username, role, level) VALUES (?, ?, ?, ?);",
        (message.from_user.id, message.from_user.username or "", "owner", 6)
    )
    await message.answer("✅ Выдан уровень 6 (Владелец).")


@router.message(Command("setadmin"))
async def cmd_setadmin(message: Message, state: FSMContext):
    admin_id = message.from_user.id
    admin_level = await get_admin_level(db, admin_id) or 0

    if admin_level < 5:
        return await message.answer("❌ Только администраторы уровня 5 могут использовать эту команду.")

    await message.answer(
        "🔹 Введите <code>user_id</code> пользователя, которому хотите выдать админку:",
        parse_mode=ParseMode.HTML
    )
    await state.set_state(SetAdminState.waiting_for_user_id)


@router.message(SetAdminState.waiting_for_user_id)
async def process_user_id(message: Message, state: FSMContext):
    if not message.text.isdigit():
        return await message.answer("❌ Введите корректный числовой user_id.")
    await state.update_data(user_id=int(message.text))
    await message.answer("🔹 Введите название роли (например: moderator):")
    await state.set_state(SetAdminState.waiting_for_role)


@router.message(SetAdminState.waiting_for_role)
async def process_role(message: Message, state: FSMContext):
    role = message.text.strip()
    if not role:
        return await message.answer("❌ Роль не может быть пустой.")
    await state.update_data(role=role)
    await message.answer("🔹 Введите уровень доступа (от 1 до 6):")
    await state.set_state(SetAdminState.waiting_for_level)


@router.message(SetAdminState.waiting_for_level)
async def process_level(message: Message, state: FSMContext):
    try:
        level = int(message.text.strip())
    except ValueError:
        return await message.answer("❌ Введите корректное число.")
    if not (1 <= level <= 6):
        return await message.answer("❌ Уровень должен быть от 1 до 6.")

    data = await state.get_data()
    user_id = data["user_id"]
    role = data["role"]

    await db.execute(
        "INSERT OR REPLACE INTO admins (user_id, username, role, level) "
        "VALUES (?, COALESCE((SELECT username FROM users WHERE user_id = ?), ''), ?, ?);",
        (user_id, user_id, role, level)
    )

    await message.answer(
        f"✅ Пользователю <code>{user_id}</code> выдана роль <b>{role}</b> с уровнем <code>{level}</code>.",
        parse_mode=ParseMode.HTML,
        reply_markup=ReplyKeyboardRemove()
    )
    await state.clear()

cancel_button = InlineKeyboardButton(text="❌ Отмена", callback_data="give_cancel")
cancel_keyboard_inline = InlineKeyboardMarkup(inline_keyboard=[[cancel_button]])

ADMIN_LIMITS = {
    2: {"paketcoin": 1, "donatecoin": 0},
    3: {"paketcoin": 1, "donatecoin": 0},
    4: {"paketcoin": 2_000_000, "donatecoin": 300},
    5: {"paketcoin": 5_000_000, "donatecoin": 500},
    6: {"paketcoin": 100_000_000_000_000, "donatecoin": 100000000},
}

@router.message(Command("agive"))
async def give_start_handler(message: Message, state: FSMContext):
    admin_id = message.from_user.id
    admin_level = await get_admin_level(db, admin_id)
    if not admin_level or admin_level < 2:
        return await message.answer("❌ У вас нет прав.")
    
    sent_message = await message.answer(
        "💬 Введите ID пользователя, которому хотите выдать средства:",
        reply_markup=cancel_keyboard_inline
    )
    await state.set_state(GiveState.user_id)
    await state.update_data(
        admin_id=admin_id,
        admin_level=admin_level,
        message_id=sent_message.message_id,
        chat_id=sent_message.chat.id
    )


@router.message(GiveState.user_id, F.text.casefold() != "отмена")
async def give_user_id_handler(message: Message, state: FSMContext):
    data = await state.get_data()
    chat_id = data["chat_id"]
    message_id = data["message_id"]
    input_text = message.text.strip()

    user_id = None

    if input_text.startswith("@"):
        username = input_text[1:].lower()
        row = await db._conn.execute("SELECT user_id FROM users WHERE LOWER(username) = ?", (username,))
        result = await row.fetchone()
        if result:
            user_id = result[0]
        else:
            await message.bot.edit_message_text(
                "❌ Пользователь с таким username не найден.",
                chat_id=chat_id,
                message_id=message_id,
                reply_markup=cancel_keyboard_inline
            )
            return
    else:
        try:
            user_id = int(input_text)
            if user_id <= 0:
                raise ValueError
        except ValueError:
            await message.bot.edit_message_text(
                "❌ Введите корректный ID или @username.",
                chat_id=chat_id,
                message_id=message_id,
                reply_markup=cancel_keyboard_inline
            )
            return

    user = await get_user(db, user_id)
    if not user:
        await message.bot.edit_message_text(
            "❌ Пользователь не найден.",
            chat_id=chat_id,
            message_id=message_id,
            reply_markup=cancel_keyboard_inline
        )
        return


    await state.update_data(user_id=user_id)

    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💎 PaketCoin", callback_data="give_currency_paketcoin")],
        [InlineKeyboardButton(text="💰 DonateCoin", callback_data="give_currency_donatecoin")],
        [cancel_button]
    ])
    await message.bot.edit_message_text(
        "💲 Выберите валюту:",
        chat_id=chat_id,
        message_id=message_id,
        reply_markup=keyboard
    )
    await state.set_state(GiveState.currency)


@router.callback_query(F.data.startswith("give_currency_"))
async def give_currency_handler(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    if callback.from_user.id != data.get("admin_id"):
        return await callback.answer("⛔ Только вы можете продолжить.", show_alert=True)

    currency = callback.data.split("_")[2]
    await state.update_data(currency=currency)

    chat_id = callback.message.chat.id
    message_id = callback.message.message_id

    await callback.bot.edit_message_text(
        f"Вы выбрали: {currency.capitalize()}\n\n🔢 Введите сумму:",
        chat_id=chat_id,
        message_id=message_id,
        reply_markup=cancel_keyboard_inline
    )
    await state.set_state(GiveState.amount)
    await callback.answer()


@router.message(GiveState.amount, F.text.casefold() != "отмена")
async def give_amount_handler(message: Message, state: FSMContext):
    data = await state.get_data()
    chat_id = data["chat_id"]
    message_id = data["message_id"]

    try:
        amount = int(message.text)
    except ValueError:
        await message.bot.edit_message_text(
            "❌ Сумма должна быть числом.",
            chat_id=chat_id,
            message_id=message_id,
            reply_markup=cancel_keyboard_inline
        )
        return

    if amount <= 0:
        await message.bot.edit_message_text(
            "❌ Сумма должна быть больше нуля.",
            chat_id=chat_id,
            message_id=message_id,
            reply_markup=cancel_keyboard_inline
        )
        return

    user_id = data["user_id"]
    currency = data["currency"]
    admin_level = data["admin_level"]

    limits = ADMIN_LIMITS.get(admin_level, {})
    limit = limits.get(currency, 0)

    if amount > limit:
        await message.bot.edit_message_text(
            f"❌ Лимит для вашей роли: {limit:,} {currency.capitalize()}.",
            chat_id=chat_id,
            message_id=message_id,
            reply_markup=cancel_keyboard_inline
        )
        return

    try:
        if currency == "paketcoin":
            await add_kazna_balance(db, -int(amount))
            await db.execute("UPDATE users SET balance = balance + ? WHERE user_id = ?", (amount, user_id))
        elif currency == "donatecoin":
            await db.execute("UPDATE users SET donatecoin = donatecoin + ? WHERE user_id = ?", (amount, user_id))
        else:
            await message.bot.edit_message_text(
                "❌ Неизвестная валюта.",
                chat_id=chat_id,
                message_id=message_id,
                reply_markup=cancel_keyboard_inline
            )
            return
        
        await message.bot.edit_message_text(
            f"✅ Пользователю <code>{user_id}</code> выдано <b>{amount:,}</b> {currency.capitalize()}.",
            chat_id=chat_id,
            message_id=message_id,
            parse_mode=ParseMode.HTML,
            reply_markup=None
        )
    except Exception as e:
        await message.bot.edit_message_text(
            f"❌ Ошибка при выдаче: {e}",
            chat_id=chat_id,
            message_id=message_id,
            reply_markup=None
        )
    finally:
        await state.clear()


@router.callback_query(F.data == "give_cancel")
async def give_cancel_callback(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    if callback.from_user.id != data.get("admin_id"):
        return await callback.answer("⛔ Только вы можете отменить эту операцию.", show_alert=True)

    chat_id = callback.message.chat.id
    message_id = callback.message.message_id

    await state.clear()
    await callback.bot.edit_message_text(
        "🚫 Операция отменена.",
        chat_id=chat_id,
        message_id=message_id,
        reply_markup=None
    )
    await callback.answer()

cancel_button = InlineKeyboardButton(text="❌ Отмена", callback_data="send_cancel")
confirm_button = InlineKeyboardButton(text="✅ Подтвердить", callback_data="send_confirm")
confirm_kb = InlineKeyboardMarkup(inline_keyboard=[[confirm_button, cancel_button]])

skip_button = InlineKeyboardButton(text="➡️ Пропустить", callback_data="send_skip")
media_kb = InlineKeyboardMarkup(inline_keyboard=[[cancel_button, skip_button]])


@router.message(Command("send"))
async def cmd_send_start(message: Message, state: FSMContext):
    admin_id = message.from_user.id
    admin_level = await get_admin_level(db, admin_id)
    if not admin_level or admin_level < 4:  # например, минимум уровень 4
        return await message.answer("❌ У вас нет прав на рассылку.")

    await message.answer(
        "📝 Введите текст рассылки. Можно использовать HTML-разметку.\n\n"
        "Если хотите отправить только медиа без текста, введите '-' (дефис).",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[cancel_button]])
    )
    await state.set_state(SendBroadcastState.waiting_for_text)

@router.message(SendBroadcastState.waiting_for_text, F.text.casefold() != "отмена")
async def process_broadcast_text(message: Message, state: FSMContext):
    text = message.text.strip()
    await state.update_data(broadcast_text=None if text == "-" else text)

    await message.answer(
        "📸 Теперь отправьте фото или видео для рассылки (опционально), либо нажмите кнопку «Пропустить», чтобы расслать без медиа.",
        reply_markup=media_kb
    )
    await state.set_state(SendBroadcastState.waiting_for_media)

@router.callback_query(F.data == "send_skip", SendBroadcastState.waiting_for_media)
async def skip_media_callback(callback: CallbackQuery, state: FSMContext):
    await state.update_data(media=None)
    await confirm_broadcast(callback.message, state)
    await callback.answer()

@router.message(SendBroadcastState.waiting_for_media, F.content_type.in_({ContentType.PHOTO, ContentType.VIDEO}))
async def receive_media(message: Message, state: FSMContext):
    if message.photo:
        file_id = message.photo[-1].file_id  # лучшее качество
        media_type = "photo"
    elif message.video:
        file_id = message.video.file_id
        media_type = "video"
    else:
        return await message.answer("❌ Поддерживаются только фото или видео.")

    await state.update_data(media={"file_id": file_id, "type": media_type})
    await confirm_broadcast(message, state)

async def confirm_broadcast(message: Message, state: FSMContext):
    data = await state.get_data()
    text = data.get("broadcast_text") or "(без текста)"
    media = data.get("media")

    preview = ""
    if media:
        preview = f"📎 Медиа: {media['type']}\n"

    await message.answer(
        f"⚠️ Подтвердите рассылку:\n\n{text}\n\n{preview}",
        reply_markup=confirm_kb,
        parse_mode=ParseMode.HTML
    )
    await state.set_state(SendBroadcastState.waiting_for_confirm)

@router.callback_query(F.data == "send_cancel", SendBroadcastState.waiting_for_confirm)
@router.callback_query(F.data == "send_cancel", SendBroadcastState.waiting_for_media)
@router.callback_query(F.data == "send_cancel", SendBroadcastState.waiting_for_text)
async def send_cancel_callback(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.edit_text("🚫 Рассылка отменена.", reply_markup=None)
    await callback.answer()

@router.callback_query(F.data == "send_confirm", SendBroadcastState.waiting_for_confirm)
async def send_confirm_callback(callback: CallbackQuery, state: FSMContext):
    await callback.answer("⚙️ Начинаю рассылку...")
    data = await state.get_data()
    text = data.get("broadcast_text")
    media = data.get("media")

    # Получаем список пользователей из БД
    rows = await db._conn.execute("SELECT user_id FROM users WHERE is_banned = 0")
    users = await rows.fetchall()
    users_ids = [row[0] for row in users]

    sent = 0
    failed = 0

    for user_id in users_ids:
        try:
            if media:
                if media["type"] == "photo":
                    await callback.bot.send_photo(chat_id=user_id, photo=media["file_id"], caption=text or None, parse_mode=ParseMode.HTML)
                elif media["type"] == "video":
                    await callback.bot.send_video(chat_id=user_id, video=media["file_id"], caption=text or None, parse_mode=ParseMode.HTML)
            else:
                if text:
                    await callback.bot.send_message(chat_id=user_id, text=text, parse_mode=ParseMode.HTML)
                else:
                    # Если нет текста и нет медиа — пропускаем
                    continue
            sent += 1
        except Exception:
            failed += 1
            # Можно логировать исключение, если нужно
        await asyncio.sleep(0.05)  # маленькая задержка, чтобы не спамить сильно

    await callback.message.edit_text(
        f"✅ Рассылка завершена.\n\n"
        f"Отправлено: {sent}\n"
        f"Не доставлено: {failed}"
    )
    await state.clear()

@router.message(Command("delete"))
async def cmd_delete_user(message: Message):
    admin_id = message.from_user.id
    admin_level = await get_admin_level(db, admin_id)
    if not admin_level or admin_level < 5:  # например, требуем уровень 5+
        return await message.answer("❌ У вас нет прав для удаления пользователей.")

    parts = message.text.split()
    if len(parts) != 2 or not parts[1].isdigit():
        return await message.answer("Использование: /delete <ChatId>")

    user_id = int(parts[1])

    # Проверяем, что пользователь существует
    user = await get_user(db, user_id)
    if not user:
        return await message.answer(f"❌ Пользователь с ID {user_id} не найден.")

    try:
        await db._conn.execute("BEGIN")

        # Удаляем из связанных таблиц
        await db._conn.execute("DELETE FROM admins WHERE user_id = ?", (user_id,))
        await db._conn.execute("DELETE FROM bank_accounts WHERE user_id = ?", (user_id,))
        await db._conn.execute("DELETE FROM bonus_claims WHERE user_id = ?", (user_id,))
        await db._conn.execute("DELETE FROM case_openings WHERE user_id = ?", (user_id,))
        await db._conn.execute("DELETE FROM games WHERE user_id = ?", (user_id,))
        await db._conn.execute("DELETE FROM promocode_claims WHERE user_id = ?", (user_id,))
        await db._conn.execute("DELETE FROM referrals WHERE user_id = ? OR invited = ?", (user_id, user_id))
        await db._conn.execute("DELETE FROM transfers WHERE from_user_id = ? OR to_user_id = ?", (user_id, user_id))
        await db._conn.execute("DELETE FROM user_streaks WHERE user_id = ?", (user_id,))

        # Удаляем самого пользователя
        await db._conn.execute("DELETE FROM users WHERE user_id = ?", (user_id,))

        await db._conn.execute("COMMIT")
    except Exception as e:
        await db._conn.execute("ROLLBACK")
        return await message.answer(f"❌ Ошибка при удалении пользователя: {e}")

    await message.answer(f"✅ Пользователь с ID {user_id} успешно удалён из базы данных.")


@router.message(Command("stats"))
async def stats_handler(message: Message):
    admin_id = message.from_user.id
    level = await get_admin_level(db, admin_id)
    if level < 3:
        await message.answer("❌ У вас недостаточно прав для использования этой команды.")
        return

    now = datetime.utcnow()
    day_ago = now - timedelta(days=1)
    day_ago_str = day_ago.strftime("%Y-%m-%d %H:%M:%S")

    queries = {
        "total_users": "SELECT COUNT(*) FROM users;",
        "new_users_day": "SELECT COUNT(*) FROM users WHERE registered_at >= ?;",
        "banned_users": "SELECT COUNT(*) FROM users WHERE is_banned = 1;",
        "games_total": "SELECT COUNT(*) FROM games;",
        "games_day": "SELECT COUNT(*) FROM games WHERE created_at >= ?;",
        "bonus_claims_total": "SELECT COUNT(*) FROM bonus_claims;",
        "bonus_claims_day": "SELECT COUNT(*) FROM bonus_claims WHERE claimed_at >= ?;",
        "bank_balance": "SELECT COALESCE(SUM(balance), 0) FROM bank_accounts;",
        "bank_deposit": "SELECT COALESCE(SUM(deposit), 0) FROM bank_accounts;",
        "treasury_balance": "SELECT balance FROM bank_treasury WHERE id = 1;",
        "donate_total": "SELECT COALESCE(SUM(donatecoin), 0) FROM users;"
    }

    def format_num(n):
        return f"{n:,}".replace(",", ".")

    def fetch_one(query, args=()):
        return db.fetchone(query, args)

    total_users = (await fetch_one(queries["total_users"]))[0] or 0
    new_users_day = (await fetch_one(queries["new_users_day"], (day_ago_str,)))[0] or 0
    banned_users = (await fetch_one(queries["banned_users"]))[0] or 0
    games_total = (await fetch_one(queries["games_total"]))[0] or 0
    games_day = (await fetch_one(queries["games_day"], (day_ago_str,)))[0] or 0
    bonus_claims_total = (await fetch_one(queries["bonus_claims_total"]))[0] or 0
    bonus_claims_day = (await fetch_one(queries["bonus_claims_day"], (day_ago_str,)))[0] or 0
    bank_balance = (await fetch_one(queries["bank_balance"]))[0] or 0
    bank_deposit = (await fetch_one(queries["bank_deposit"]))[0] or 0
    treasury_row = await fetch_one(queries["treasury_balance"])
    treasury_balance = treasury_row[0] if treasury_row else 0
    donate_total = (await fetch_one(queries["donate_total"]))[0] or 0

    text = (
        f"<b>📊 Статистика бота</b>\n"
        f"<code>·····················</code>\n"
        f"├ 👥 <i>Пользователей всего:</i> <b>{format_num(total_users)}</b>\n"
        f"├ 🆕 <i>Новых за 24ч:</i> <b>{format_num(new_users_day)}</b>\n"
        f"├ 🚫 <i>Забанено:</i> <b>{format_num(banned_users)}</b>\n"
        f"<code>·····················</code>\n"
        f"├ 🎮 <i>Игр всего:</i> <b>{format_num(games_total)}</b>\n"
        f"├ ⏱️ <i>Игр за 24ч:</i> <b>{format_num(games_day)}</b>\n"
        f"<code>·····················</code>\n"
        f"├ 🎁 <i>Бонусов всего:</i> <b>{format_num(bonus_claims_total)}</b>\n"
        f"├ 🕐 <i>Бонусов за 24ч:</i> <b>{format_num(bonus_claims_day)}</b>\n"
        f"<code>·····················</code>\n"
        f"├ 💰 <i>Сумма на счетах:</i> <b>{format_num(bank_balance)}</b> PaketCoins\n"
        f"├ 🏦 <i>Всего на депозитах:</i> <b>{format_num(bank_deposit)}</b> PaketCoins\n"
        f"├ 🏛️ <i>Баланс казны:</i> <b>{format_num(treasury_balance)}</b> PaketCoins\n"
        f"<code>·····················</code>\n"
        f"├ 💎 <i>Всего доната:</i> <b>{format_num(donate_total)}</b> DonateCoins\n"
        f"<code>·····················</code>\n"
        f"<blockquote>👮 <i>Ваша роль:</i> <b>{get_role_name_by_level(level)}</b></blockquote>"
    )

    await message.answer(text, parse_mode=ParseMode.HTML)
