from aiogram import Router, types, F
from aiogram.filters import Command
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
import psutil
import time
import asyncio
from datetime import datetime
from aiogram.enums import ParseMode

router = Router()

def usage_bar(usage: float, length: int = 10) -> str:
    full_blocks = int(usage / 100 * length)
    empty_blocks = length - full_blocks
    bar = "█" * full_blocks + "░" * empty_blocks
    return f"|{bar}|"

async def get_status_text() -> str:
    cpu = psutil.cpu_percent(interval=0.3)
    mem = psutil.virtual_memory()
    mem_percent = mem.percent
    ping_ms = round(psutil.net_io_counters().packets_sent % 1000 + time.time() % 100)  # пример пинга
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    text = (
        f"📡 Пинг: <b>{ping_ms:.2f} мс</b>\n"
        f"🖥 CPU: <b>{cpu:.1f}%</b> {usage_bar(cpu)}\n"
        f"🧠 Память: <b>{mem_percent:.1f}%</b> {usage_bar(mem_percent)}\n\n"
        f"<code>·····················</code>\n"
        f"🕒 Время: <b>{now_str}</b>"
    )
    return text

@router.message(Command("ping"))
async def ping_handler(message: Message):
    await message.bot.send_chat_action(message.chat.id, action="typing")
    text = await get_status_text()

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔄 Обновить", callback_data="ping_refresh")]
    ])

    await message.answer(text, reply_markup=kb, parse_mode="HTML")

@router.callback_query(F.data == "ping_refresh")
async def ping_refresh_handler(callback: types.CallbackQuery):
    await callback.message.edit_text("<b><i>Обновление ..</i></b>", parse_mode="HTML")
    await asyncio.sleep(1)
    await callback.message.edit_text("<b><i>Обновление ...</i></b>", parse_mode="HTML")
    await asyncio.sleep(1)

    text = await get_status_text()

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔄 Обновить", callback_data="ping_refresh")]
    ])

    await callback.message.edit_text(text, parse_mode="HTML", reply_markup=kb)
    await callback.answer()


@router.message(Command("getid"))
async def get_id_handler(message: Message):
    if message.reply_to_message:
        target_user = message.reply_to_message.from_user

        if target_user.is_bot:
            await message.answer(
                "🤖 <i>ID ботов недоступен по соображениям безопасности.</i>",
                parse_mode=ParseMode.HTML
            )
            return

        target_id = target_user.id
        target_name = f"@{target_user.username}" if target_user.username else f"{target_user.full_name}"

        text = (
            f"📦 <b>Информация о пользователе</b>\n"
            f"<code>·····················</code>\n"
            f"├ 🧾 <i>Имя:</i> <b>{target_name}</b>\n"
            f"├ 🆔 <i>ID:</i> <code>{target_id}</code>\n"
            f"<code>·····················</code>"
        )
    else:
        chat_id = message.chat.id
        chat_title = message.chat.title or "Без названия"

        text = (
            f"📦 <b>Информация о чате</b>\n"
            f"<code>·····················</code>\n"
            f"├ 🧾 <i>Название:</i> <b>{chat_title}</b>\n"
            f"├ 🆔 <i>ID чата:</i> <code>{chat_id}</code>\n"
            f"<code>·····················</code>"
        )

    await message.answer(text, parse_mode=ParseMode.HTML)