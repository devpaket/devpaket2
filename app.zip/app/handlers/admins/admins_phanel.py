from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.enums.parse_mode import ParseMode
from aiogram.fsm.state import StatesGroup, State
from aiogram.types import ReplyKeyboardRemove
from database.setup import Database
from utils.admin import is_admin, get_admin_level, get_role_name_by_level
from config import load_config

config = load_config()
db = Database(config.bot.database)

router = Router()

class AdminManageState(StatesGroup):
    waiting_for_role = State()
    waiting_for_level = State()

# Клавиатура отмены
cancel_kb = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="❌ Отмена", callback_data="admin_manage_cancel")]
])

async def get_admins_list_keyboard(db):
    admins = await db.fetchall("SELECT user_id, username, role, level FROM admins ORDER BY level DESC;")
    keyboard = InlineKeyboardMarkup(inline_keyboard=[])  # пустой список кнопок

    for admin in admins:
        user_id, username, role, level = admin
        text = f"{username or '—'} ({user_id}) — {role} [{level}]"
        button = InlineKeyboardButton(text=text, callback_data=f"admin_select_{user_id}")
        keyboard.inline_keyboard.append([button])  # добавляем кнопку в новую строку

    close_button = InlineKeyboardButton(text="❌ Закрыть", callback_data="admin_manage_cancel")
    keyboard.inline_keyboard.append([close_button])

    return keyboard
@router.message(Command("admins"))
async def admin_manage_start(message: Message, state: FSMContext):
    admin_level = await get_admin_level(db, message.from_user.id) or 0
    if admin_level < 6:
        return await message.answer("❌ Только админы уровня 6 могут управлять администраторами.")

    kb = await get_admins_list_keyboard(db)
    await message.answer("📋 Список администраторов. Выберите для управления:", reply_markup=kb)
    await state.clear()

@router.callback_query(F.data.startswith("admin_select_"))
async def admin_select_handler(callback: CallbackQuery, state: FSMContext):
    admin_level = await get_admin_level(db, callback.from_user.id) or 0
    if admin_level < 6:
        return await callback.answer("❌ Нет доступа.", show_alert=True)

    target_user_id = int(callback.data.split("_")[2])
    await state.update_data(target_user_id=target_user_id, admin_level=admin_level, initiator_id=callback.from_user.id)

    admin_data = await db.fetchone("SELECT user_id, username, role, level FROM admins WHERE user_id = ?", (target_user_id,))
    if not admin_data:
        await callback.answer("❌ Администратор не найден.", show_alert=True)
        return

    user_id, username, role, level = admin_data
    text = (
        f"👤 Админ: {username or '—'} ({user_id})\n"
        f"Роль: <b>{role}</b>\n"
        f"Уровень: <code>{level}</code>\n\n"
        f"Что хотите сделать?"
    )

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✏️ Изменить роль", callback_data="admin_edit_role")],
        [InlineKeyboardButton(text="🗑 Удалить администратора", callback_data="admin_delete")],
        [InlineKeyboardButton(text="❌ Отмена", callback_data="admin_manage_cancel")]
    ])

    await callback.message.edit_text(text, reply_markup=kb, parse_mode=ParseMode.HTML)
    await callback.answer()

@router.callback_query(F.data == "admin_edit_role")
async def admin_edit_role(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    if callback.from_user.id != data.get("initiator_id"):
        return await callback.answer("⛔ Только инициатор может редактировать.", show_alert=True)

    await callback.message.edit_text(
        "Введите новую роль для администратора (например, moderator):",
        reply_markup=cancel_kb
    )
    await state.set_state(AdminManageState.waiting_for_role)
    await callback.answer()

@router.message(AdminManageState.waiting_for_role)
async def process_new_role(message: Message, state: FSMContext):
    if message.text.lower() == "отмена":
        await state.clear()
        return await message.answer("🚫 Операция отменена.", reply_markup=ReplyKeyboardRemove())

    role = message.text.strip()
    if not role:
        return await message.answer("❌ Роль не может быть пустой. Попробуйте ещё раз.")

    await state.update_data(new_role=role)
    await message.answer("Введите новый уровень доступа (1-6):", reply_markup=cancel_kb)
    await state.set_state(AdminManageState.waiting_for_level)

@router.message(AdminManageState.waiting_for_level)
async def process_new_level(message: Message, state: FSMContext):
    if message.text.lower() == "отмена":
        await state.clear()
        return await message.answer("🚫 Операция отменена.", reply_markup=ReplyKeyboardRemove())

    try:
        level = int(message.text.strip())
    except ValueError:
        return await message.answer("❌ Введите корректное число.")

    if not (1 <= level <= 6):
        return await message.answer("❌ Уровень должен быть от 1 до 6.")

    data = await state.get_data()
    target_user_id = data.get("target_user_id")
    new_role = data.get("new_role")

    # Обновляем в БД
    await db.execute(
        "UPDATE admins SET role = ?, level = ? WHERE user_id = ?;",
        (new_role, level, target_user_id)
    )

    await message.answer(
        f"✅ Роль администратора <code>{target_user_id}</code> изменена на <b>{new_role}</b> с уровнем <code>{level}</code>.",
        parse_mode=ParseMode.HTML,
        reply_markup=ReplyKeyboardRemove()
    )
    await state.clear()

@router.callback_query(F.data == "admin_delete")
async def admin_delete_handler(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    if callback.from_user.id != data.get("initiator_id"):
        return await callback.answer("⛔ Только инициатор может удалять.", show_alert=True)

    target_user_id = data.get("target_user_id")

    await db.execute("DELETE FROM admins WHERE user_id = ?", (target_user_id,))
    await callback.message.edit_text(f"🗑 Администратор <code>{target_user_id}</code> успешно удалён.", parse_mode=ParseMode.HTML)
    await state.clear()
    await callback.answer()

@router.callback_query(F.data == "admin_manage_cancel")
async def admin_manage_cancel_handler(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    if callback.from_user.id != data.get("initiator_id", callback.from_user.id):
        return await callback.answer("⛔ Только инициатор может отменить.", show_alert=True)

    await state.clear()
    await callback.message.edit_text("🚫 Управление администраторами отменено.", reply_markup=None)
    await callback.answer()
