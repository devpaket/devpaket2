from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.filters import Command, or_f
from aiogram.enums.parse_mode import ParseMode
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from keyboards.bank import bank_keyboard, back_to_bank_menu_keyboard
from database.queries import (
    get_user, get_bank_account, create_bank_account,
    update_bank_account, update_user_balance, add_kazna_balance
)
from database.setup import Database
from config import load_config
import re
from datetime import datetime

router = Router()
config = load_config()
db = Database(config.bot.database)
print("[Log] Router Bank запущен")

def cancel_transfer_keyboard(user_id: int):
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🚫 Отмена", callback_data=f"cancel_transfer:{user_id}")]
        ]
    )

def is_new_day(last_date: str) -> bool:
    if not last_date:
        return True
    try:
        return datetime.utcnow().date() > datetime.fromisoformat(last_date).date()
    except Exception:
        return True

class BankFSM(StatesGroup):
    depositing = State()
    withdrawing = State()
    waiting_recipient_id = State()
    waiting_transfer_amount = State()


def format_user(user) -> str:
    username = user.username
    first_name = user.first_name or "Пользователь"
    if username:
        return f"<a href='https://t.me/{username}'>{first_name}</a>"
    else:
        return first_name


def format_amount(amount: int) -> str:
    return f"{amount:,}".replace(",", ".")


def parse_amount_input(text: str, available: int) -> int | None:
    normalized = text.lower().replace(" ", "")
    if normalized in {"все", "всё"}:
        return available

    multiplier = 1
    match = re.fullmatch(r"(\d+)(к{1,3})?", normalized)
    if not match:
        return None

    number = int(match.group(1))
    k_suffix = match.group(2)

    if k_suffix:
        multiplier = 10 ** (3 * len(k_suffix))

    return number * multiplier




@router.message(or_f(Command("bank"), F.text.casefold() == "банк"))
async def bank_menu(message: Message, state: FSMContext):
    user = message.from_user
    user_id = user.id

    user_data = await get_user(db, user_id)
    if not user_data:
        await message.answer("❌ Профиль не найден.", parse_mode=ParseMode.HTML)
        return

    bank_account = await get_bank_account(db, user_id)
    if not bank_account:
        await create_bank_account(db, user_id)
        bank_account = await get_bank_account(db, user_id)

    text = (
        f"<b>🏦 PaketBank</b>\n"
        f"<code>·····················</code>\n"
        f"👤 Владелец: {format_user(user)} #<code>{user_id}</code>\n"
        f"💳 Баланс счёта: <b><code>{format_amount(bank_account['balance'])}</code></b> PaketCoin\n"
        f"💰 Депозит: <b><code>{format_amount(bank_account['deposit'])}</code></b> PaketCoin\n"
        f"<code>·····················</code>\n"
    )

    await message.answer(
        text, parse_mode=ParseMode.HTML,
        reply_markup=bank_keyboard(user_id),
        disable_web_page_preview=True
    )
    await state.clear()


async def is_owner(callback: CallbackQuery, target_user_id: int) -> bool:
    if callback.from_user.id != target_user_id:
        await callback.answer("❌ Это меню принадлежит другому пользователю.", show_alert=True)
        return False
    return True

@router.callback_query(F.data.startswith("bank_pay:"))
async def pay_start(callback: CallbackQuery, state: FSMContext):
    user_id = int(callback.data.split(":")[1])
    if callback.from_user.id != user_id:
        await callback.answer("⛔ Это меню не для вас.", show_alert=True)
        return

    text = (
        f"<b>🏦 PaketBank -> Перевод через СБП 🟢</b>\n"
        f"<code>·····················</code>\n"
        f"💳 Введите <b>ID счёта</b> получателя:\n"
        f"<code>·····················</code>\n"
    )

    await state.update_data(sender_id=user_id, message_id=callback.message.message_id)
    await callback.message.edit_text(text, parse_mode=ParseMode.HTML, reply_markup=cancel_transfer_keyboard(user_id))
    await state.set_state(BankFSM.waiting_recipient_id)
    await callback.answer()

@router.message(BankFSM.waiting_recipient_id)
async def receive_recipient_id(message: Message, state: FSMContext):
    data = await state.get_data()
    sender_id = data.get("sender_id")
    msg_id = data.get("message_id")

    if not message.text.isdigit():
        await message.bot.edit_message_text(
            chat_id=message.chat.id,
            message_id=msg_id,
            text="⚠️ Введите корректный ID (числом).",
            parse_mode=ParseMode.HTML,
            reply_markup=cancel_transfer_keyboard(sender_id)
        )
        return

    recipient_id = int(message.text)
    if recipient_id == sender_id:
        await message.bot.edit_message_text(
            chat_id=message.chat.id,
            message_id=msg_id,
            text="❌ Нельзя переводить самому себе.",
            parse_mode=ParseMode.HTML,
            reply_markup=cancel_transfer_keyboard(sender_id)
        )
        return

    recipient_bank = await get_bank_account(db, recipient_id)
    if not recipient_bank:
        await create_bank_account(db, recipient_id)

    text = (
        f"<b>🏦 PaketBank -> Перевод через СБП 🟢</b>\n"
        f"<code>·····················</code>\n"
        f"💰 Введите сумму перевода:\n"
        f"<code>·····················</code>\n"
    )

    await state.update_data(recipient_id=recipient_id)
    await message.bot.edit_message_text(
        chat_id=message.chat.id,
        message_id=msg_id,
        text=text,
        parse_mode=ParseMode.HTML,
        reply_markup=cancel_transfer_keyboard(sender_id)
    )
    await state.set_state(BankFSM.waiting_transfer_amount)

@router.message(BankFSM.waiting_transfer_amount)
async def receive_transfer_amount(message: Message, state: FSMContext):
    data = await state.get_data()
    sender_id = data.get("sender_id")
    recipient_id = data.get("recipient_id")
    message_id = data.get("message_id")

    sender_bank = await get_bank_account(db, sender_id)
    recipient_bank = await get_bank_account(db, recipient_id)

    amount = parse_amount_input(message.text, sender_bank["balance"])
    if amount is None or amount <= 0:
        return await message.bot.edit_message_text(
            chat_id=message.chat.id,
            message_id=message_id,
            text="⚠️ Введите корректную сумму (например: <code>1к</code>, <code>все</code>).",
            parse_mode=ParseMode.HTML,
            reply_markup=cancel_transfer_keyboard(sender_id)
        )

    if amount > 3_000_000:
        return await message.bot.edit_message_text(
            chat_id=message.chat.id,
            message_id=message_id,
            text="❌ Лимит одного перевода — <b>3.000.000 PaketCoin</b>.",
            parse_mode=ParseMode.HTML,
            reply_markup=cancel_transfer_keyboard(sender_id)
        )

    if is_new_day(sender_bank.get("last_transfer")):
        sender_bank["daily_limit"] = 0

    if sender_bank["daily_limit"] + amount > 3_000_000:
        return await message.bot.edit_message_text(
            chat_id=message.chat.id,
            message_id=message_id,
            text="❌ Превышен суточный лимит переводов (3.000.000 PaketCoin).",
            parse_mode=ParseMode.HTML,
            reply_markup=cancel_transfer_keyboard(sender_id)
        )

    if sender_bank["balance"] < amount:
        return await message.bot.edit_message_text(
            chat_id=message.chat.id,
            message_id=message_id,
            text="❌ Недостаточно средств на банковском счёте.",
            parse_mode=ParseMode.HTML,
            reply_markup=cancel_transfer_keyboard(sender_id)
        )

    commission = amount * 3 // 100
    final_amount = amount - commission

    await update_bank_account(db, sender_id, sender_bank["balance"] - amount)
    await update_bank_account(db, recipient_id, recipient_bank["balance"] + final_amount)
    await add_kazna_balance(db, commission)

    new_daily_limit = sender_bank["daily_limit"] + amount
    now_str = datetime.utcnow().isoformat()

    await db.execute(
        "UPDATE bank_accounts SET daily_limit = ?, last_transfer = ? WHERE user_id = ?",
        (new_daily_limit, now_str, sender_id)
    )
    await db.commit()

    recipient_user = await message.bot.get_chat(recipient_id)

    text = (
        f"<b>🏦 PaketBank -> Перевод через СБП 🟢</b>\n"
        f"<code>·····················</code>\n"
        f"📤 {format_user(message.from_user)} перевёл <b>{format_amount(amount)}</b> PaketCoin "
        f"{format_user(recipient_user)}\n"
        f"💸 Комиссия: <b>{format_amount(commission)}</b> PaketCoin\n"
        f"📥 Получено: <b>{format_amount(final_amount)}</b> PaketCoin\n"
        f"<code>·····················</code>\n"
        f"<blockquote><code><b> Статус перевода: Успешно ✅</b></code></blockquote>"
    )

    await message.bot.edit_message_text(
        chat_id=message.chat.id,
        message_id=message_id,
        text=text,
        parse_mode=ParseMode.HTML,
        reply_markup=back_to_bank_menu_keyboard(sender_id),
        disable_web_page_preview=True
    )

    try:
        await message.bot.send_message(
            chat_id=recipient_id,
            text=(
                f"<b>🏦 PaketBank -> Перевод через СБП 🟢</b>\n"
                f"<code>·····················</code>\n"
                f"📥 Вам поступил перевод от {format_user(message.from_user)}!\n"
                f"💰 Сумма: <b>{format_amount(final_amount)}</b> PaketCoin\n"
                f"<code>·····················</code>\n"
                f"<blockquote><code><b> Статус перевода: Успешно ✅</b></code></blockquote>"
            ),
            parse_mode=ParseMode.HTML,
            disable_web_page_preview=True
        )
    except Exception:
        pass

    await state.clear()

@router.callback_query(F.data.startswith("cancel_transfer:"))
async def cancel_transfer(callback: CallbackQuery, state: FSMContext):
    user_id = int(callback.data.split(":")[1])
    if callback.from_user.id != user_id:
        await callback.answer("⛔ Это действие не для вас.", show_alert=True)
        return

    await state.clear()
    await callback.message.edit_text("❌ Перевод отменён.", parse_mode=ParseMode.HTML)
    await callback.answer()



@router.callback_query(F.data.startswith("bank_add:"))
async def deposit_start(callback: CallbackQuery, state: FSMContext):
    user_id = int(callback.data.split(":")[1])
    if not await is_owner(callback, user_id):
        return

    await state.update_data(owner_id=user_id, message_id=callback.message.message_id)
    await callback.message.edit_text("💸 Введите сумму для пополнения банковского счёта:", parse_mode=ParseMode.HTML)
    await state.set_state(BankFSM.depositing)
    await callback.answer()


@router.callback_query(F.data.startswith("bank_withdraw:"))
async def withdraw_start(callback: CallbackQuery, state: FSMContext):
    user_id = int(callback.data.split(":")[1])
    if not await is_owner(callback, user_id):
        return

    await state.update_data(owner_id=user_id, message_id=callback.message.message_id)
    await callback.message.edit_text("🏧 Введите сумму для вывода с банковского счёта:", parse_mode=ParseMode.HTML)
    await state.set_state(BankFSM.withdrawing)
    await callback.answer()


@router.callback_query(F.data.startswith("bank_menu:"))
async def bank_menu_back(callback: CallbackQuery, state: FSMContext):
    user_id = int(callback.data.split(":")[1])

    user_data = await get_user(db, user_id)
    if not user_data:
        await callback.message.edit_text("❌ Профиль не найден.", parse_mode=ParseMode.HTML)
        return

    bank_account = await get_bank_account(db, user_id)
    if not bank_account:
        await create_bank_account(db, user_id)
        bank_account = await get_bank_account(db, user_id)

    user = callback.from_user
    text = (
        f"<b>🏦 PaketBank</b>\n"
        f"<code>·····················</code>\n"
        f"👤 Владелец: {format_user(user)} #<code>{user_id}</code>\n"
        f"💳 Баланс счёта: <b>{format_amount(bank_account['balance'])}</b> PaketCoin\n"
        f"💰 Депозит: <b>{format_amount(bank_account['deposit'])}</b> PaketCoin\n"
        f"<code>·····················</code>\n"
    )

    await callback.message.edit_text(
        text,
        parse_mode=ParseMode.HTML,
        reply_markup=bank_keyboard(user_id),
        disable_web_page_preview=True
    )
    await state.clear()
    await callback.answer()


@router.message(BankFSM.depositing)
async def deposit_process(message: Message, state: FSMContext):
    data = await state.get_data()
    user_id = data.get("owner_id")
    message_id = data.get("message_id")

    user = await get_user(db, user_id)
    bank_account = await get_bank_account(db, user_id)

    amount = parse_amount_input(message.text, user["balance"])
    if amount is None or amount <= 0:
        await message.answer(
            "⚠️ Введите корректную сумму (например: <code>1к</code>, <code>1кк</code>, <code>все</code>).",
            parse_mode=ParseMode.HTML
        )
        return

    if user["balance"] < amount:
        await message.answer("❌ Недостаточно средств на основном балансе.", parse_mode=ParseMode.HTML)
        return

    new_balance = bank_account["balance"] + amount

    await update_user_balance(db, user_id, user["balance"] - amount)
    await update_bank_account(db, user_id, new_balance)

    text = (
        f"<b>🏦 PaketBank</b>\n"
        f"<code>·····················</code>\n"
        f"➕ {format_user(message.from_user)}, вы пополнили банковский счёт на <b>{format_amount(amount)}</b> PaketCoin\n"
        f"<code>·····················</code>\n"
        f"📥 Текущий баланс счёта: <b>{format_amount(new_balance)}</b> PaketCoin"
    )

    try:
        await message.bot.edit_message_text(
            chat_id=message.chat.id,
            message_id=message_id,
            text=text,
            parse_mode=ParseMode.HTML,
            reply_markup=back_to_bank_menu_keyboard(user_id),
            disable_web_page_preview=True
        )
    except Exception:
        await message.answer(text, parse_mode=ParseMode.HTML, reply_markup=back_to_bank_menu_keyboard(user_id))

    await state.clear()


@router.message(BankFSM.withdrawing)
async def withdraw_process(message: Message, state: FSMContext):
    data = await state.get_data()
    user_id = data.get("owner_id")
    message_id = data.get("message_id")

    user = await get_user(db, user_id)
    bank_account = await get_bank_account(db, user_id)

    amount = parse_amount_input(message.text, bank_account["balance"])
    if amount is None or amount <= 0:
        await message.answer(
            "⚠️ Введите корректную сумму (например: <code>1к</code>, <code>1кк</code>, <code>все</code>).",
            parse_mode=ParseMode.HTML
        )
        return

    if bank_account["balance"] < amount:
        await message.answer("❌ Недостаточно средств на банковском счёте.", parse_mode=ParseMode.HTML)
        return

    new_balance = bank_account["balance"] - amount

    await update_bank_account(db, user_id, new_balance)
    await update_user_balance(db, user_id, user["balance"] + amount)

    text = (
        f"<b>🏦 PaketBank</b>\n"
        f"<code>·····················</code>\n"
        f"➖ {format_user(message.from_user)}, вы вывели с банковского счёта <b>{format_amount(amount)}</b> PaketCoin\n"
        f"<code>·····················</code>\n"
        f"📤 Текущий баланс счёта: <b>{format_amount(new_balance)}</b> PaketCoin"
    )

    try:
        await message.bot.edit_message_text(
            chat_id=message.chat.id,
            message_id=message_id,
            text=text,
            parse_mode=ParseMode.HTML,
            reply_markup=back_to_bank_menu_keyboard(user_id),
            disable_web_page_preview=True
        )
    except Exception:
        await message.answer(text, parse_mode=ParseMode.HTML, reply_markup=back_to_bank_menu_keyboard(user_id))

    await state.clear()


