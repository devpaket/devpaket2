from aiogram import Router, F
from aiogram.types import CallbackQuery, Message, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.enums.parse_mode import ParseMode
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State

from database.queries import get_user, get_bank_account, update_user_balance, update_bank_account, add_kazna_balance
from keyboards.bank import back_to_bank_menu_keyboard
from utils.time_utils import get_now, get_remaining_time, parse_duration
from database.setup import Database
from config import load_config
import datetime
import re

config = load_config()
db = Database(config.bot.database)


router = Router()
print("[Log] Router Deposit запущен")

def format_user(user) -> str:
    username = getattr(user, "username", None)
    first_name = getattr(user, "first_name", "Пользователь")

    if username:
        return f"<a href='https://t.me/{username}'>{first_name}</a>"
    else:
        return first_name

class DepositFSM(StatesGroup):
    selecting_term = State()
    confirming_deposit = State()
    withdrawing_deposit = State()
    transferring = State()
    waiting_amount = State()
    waiting_term = State()

def parse_amount_input(text: str, balance: int) -> int | None:
    text = text.lower().replace(" ", "")
    if text in ("все", "всё", "all", "Все"):
        balance = balance - 5000
        return balance

    # Поддержка суффиксов: к (тысяча), кк (миллион), ккк (миллиард)
    suffixes = {"к": 1_000, "кк": 1_000_000, "ккк": 1_000_000_000}

    match = re.fullmatch(r"(\d+)(к{0,3})", text)
    if match:
        number = int(match.group(1))
        suffix = match.group(2)
        multiplier = suffixes.get(suffix, 1)
        return number * multiplier

    # Попытка просто распарсить как число
    try:
        return int(text)
    except ValueError:
        return None

DEPOSIT_OPTIONS = {
    "1d": (1, 1.1, 0),
    "1w": (7, 3, 1.5),
    "3w": (21, 10, 4),
    "1m": (30, 15, 7),
    "3m": (90, 45, 12)
}

DEPOSIT_COST = 5_000
TRANSFER_LIMIT = 10_000_000


def format_deposit_info(account: dict, user) -> str:
    if account["deposit"] == 0:
        return "❌ У вас нет активного депозита.\n Комиссия на открытие депозита 5.000 PaketCoin"
    
    now = get_now()
    balance = f"{int(int(account['deposit']) * float(account['procent'])):,}".replace(",", ".")
    if now >= account["last_interest"]:
        path = f"<i>Сумма депозита :<b> {balance}</b> PaketCoin\n"
    else:
        path = f"<i>Сумма депозита :<b> {account['deposit']:,}</b> PaketCoin\n"

    opened = account["deposit_start"]
    duration_days = (account["last_interest"] - opened).days
    remaining = get_remaining_time(account["last_interest"])
    return (
        f"👤 Владелец: {format_user(user)}\n"
        f"{path}"
        f"Срок депозита: <b>{duration_days}</b> дн. ({remaining})\n"
        f"Процентная ставка: <b>{account['procent']}%</b></i>"
    )


def deposit_keyboard(user_id: int, account: dict) -> InlineKeyboardMarkup:
    buttons = []
    if account["deposit"] == 0:
        buttons.append([
            InlineKeyboardButton(text="➕ Открыть депозит", callback_data=f"deposit_open:{user_id}")
        ])
    else:
        now = get_now()
        if now >= account["last_interest"]:
            buttons.append([
                InlineKeyboardButton(text="🟢 Снять депозит", callback_data=f"deposit_take:{user_id}")
            ])
        else:
            buttons.append([
                InlineKeyboardButton(text="🔴 Закрыть досрочно", callback_data=f"deposit_close:{user_id}")
            ])
    buttons.append([
        InlineKeyboardButton(text="⬅️ Назад", callback_data=f"bank_menu:{user_id}")
    ])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


@router.callback_query(F.data.startswith("bank_deposit:"))
async def deposit_menu(callback: CallbackQuery):
    user_id = int(callback.data.split(":")[1])
    if callback.from_user.id != user_id:
        await callback.answer("⛔ Это меню не для вас.", show_alert=True)
        return

    account = await get_bank_account(db, user_id)
    text = "<b>🏦 PaketBank -> Депозитный счёт</b>\n"
    text += "<code>·····················</code>\n"
    text += f"{format_deposit_info(account, callback.from_user)}\n"
    text += "<code>·····················</code>\n"

    await callback.message.edit_text(
        text,
        parse_mode=ParseMode.HTML,
        reply_markup=deposit_keyboard(user_id, account),
        disable_web_page_preview=True
    )
    await callback.answer()


@router.callback_query(F.data.startswith("deposit_open:"))
async def deposit_open_amount(callback: CallbackQuery, state: FSMContext):
    user_id = int(callback.data.split(":")[1])
    if callback.from_user.id != user_id:
        await callback.answer("⛔ Это меню не для вас.", show_alert=True)
        return

    account = await get_bank_account(db, user_id)
    if account["deposit"] > 0:
        await callback.answer("У вас уже есть активный депозит.", show_alert=True)
        return

    # Рендер начального сообщения
    text = (
        f"<b>🏦 PaketBank -> Депозитный счёт</b>\n"
        f"<code>·····················</code>\n"
        f"<i>Сумма депозита:</i>\n"
        f"<i>Срок депозита:</i>\n"
        f"<i>Процентная ставка:</i>\n"
        f"<code>·····················</code>\n"
        f"📊 Выберите сумму депозита:"
    )
    sent = await callback.message.edit_text(text, parse_mode=ParseMode.HTML)

    await state.update_data(user_id=user_id, menu_msg_id=sent.message_id)
    await state.set_state(DepositFSM.waiting_amount)
    await callback.answer()


@router.message(DepositFSM.waiting_amount)
async def deposit_receive_amount(message: Message, state: FSMContext):
    data = await state.get_data()
    user_id = data.get("user_id")
    menu_msg_id = data.get("menu_msg_id")

    if message.from_user.id != user_id:
        await message.answer("⛔ Это меню не для вас.")
        return

    account = await get_bank_account(db, user_id)
    amount = parse_amount_input(message.text, account["balance"])
    if amount is None or amount <= 9999:
        await message.answer("⚠️ Минимальная сумма депозита 10000 PaketCoin")
        return

    if amount > account["balance"]:
        await message.answer("❌ Недостаточно средств на балансе.")
        return

    await state.update_data(amount=amount)

    # Формируем кнопки срока
    buttons = [[
        InlineKeyboardButton(text=f"{days} д. — {rate}%", callback_data=f"deposit_confirm:{user_id}:{key}")
    ] for key, (days, rate, _) in DEPOSIT_OPTIONS.items()]
    buttons.append([InlineKeyboardButton(text="⬅️ Отмена", callback_data=f"bank_deposit:{user_id}")])

    # Удаляем сообщение пользователя
    await message.delete()

    # Редактируем предыдущее сообщение бота
    await message.bot.edit_message_text(
        chat_id=message.chat.id,
        message_id=menu_msg_id,
        text=(
            f"<b>🏦 PaketBank -> Депозитный счёт</b>\n"
            f"<code>·····················</code>\n"
            f"<i>Сумма депозита: <b>{amount:,}</b> PaketCoin.\n</i>"
            f"<i>Срок депозита:</i>\n"
            f"<i>Процентная ставка:</i>\n"
            f"<code>·····················</code>\n"
            f"📊 Выберите срок:"
        ),
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons)
    )

    await state.set_state(DepositFSM.waiting_term)


@router.callback_query(F.data.startswith("deposit_confirm:"))
async def confirm_deposit(callback: CallbackQuery, state: FSMContext):
    parts = callback.data.split(":")
    user_id = int(parts[1])
    term_key = parts[2]

    if callback.from_user.id != user_id:
        await callback.answer("⛔ Это меню не для вас.", show_alert=True)
        return

    data = await state.get_data()
    amount = data.get("amount")
    if amount is None:
        await callback.answer("❌ Сначала введите сумму депозита.", show_alert=True)
        return

    account = await get_bank_account(db, user_id)
    if account["deposit"] > 0:
        await callback.answer("У вас уже есть активный депозит.", show_alert=True)
        return

    if account["balance"] < amount + DEPOSIT_COST:
        await callback.answer("Недостаточно средств для открытия депозита с комиссией.", show_alert=True)
        return

    days, rate, _ = DEPOSIT_OPTIONS[term_key]
    now = get_now()
    close_time = now + datetime.timedelta(days=days)

    # Списываем сумму + комиссию
    await update_bank_account(
        db, user_id,
        balance=account["balance"] - amount - DEPOSIT_COST,
        deposit=amount,
        deposit_start=now,
        last_interest=close_time,
        procent=rate
    )

    await add_kazna_balance(db, DEPOSIT_COST)
    text=(
    f"<b>🏦 PaketBank -> Депозитный счёт</b>\n"
    f"<code>·····················</code>\n"
    f"<i>Сумма депозита: <b>{amount:,}</b> PaketCoin.\n</i>"
    f"<i>Срок депозита: <b>{days}</b></i>\n"
    f"<i>Процентная ставка: <b>{rate}%</b></i>\n"
    f"<code>·····················</code>\n"
    f"✅ Депозит успешно открыт!"
    )

    await callback.message.edit_text(
        text=text,
        parse_mode=ParseMode.HTML,
        reply_markup=deposit_keyboard(user_id, await get_bank_account(db, user_id))
    )

    await callback.answer()
    await state.clear()


@router.callback_query(F.data.startswith("deposit_close:"))
async def close_deposit(callback: CallbackQuery):
    user_id = int(callback.data.split(":")[1])

    if callback.from_user.id != user_id:
        await callback.answer("⛔ Это меню не для вас.", show_alert=True)
        return

    account = await get_bank_account(db, user_id)
    if account["deposit"] == 0:
        await callback.answer("❌ У вас нет активного депозита.", show_alert=True)
        return

    key = None
    for k, (d, r, c) in DEPOSIT_OPTIONS.items():
        if r == account["procent"]:
            key = k
            break

    if not key:
        await callback.answer("⚠️ Не удалось определить условия депозита.", show_alert=True)
        return

    _, _, fee = DEPOSIT_OPTIONS[key]
    penalty = int(account["deposit"] * fee / 100)
    final_amount = account["deposit"] - penalty

    await update_bank_account(
    db,
    user_id,
    balance=account["balance"] + final_amount,
    deposit=0,
    deposit_start=None,
    last_interest=None,
    procent=None
    )

    await callback.message.edit_text(
        f"❌ Депозит закрыт досрочно. Потеряно {penalty} PaketCoin в виде комиссии.",
        parse_mode=ParseMode.HTML,
        reply_markup=deposit_keyboard(user_id, await get_bank_account(db, user_id))
    )
    await callback.answer()


@router.callback_query(F.data.startswith("deposit_take:"))
async def take_deposit(callback: CallbackQuery):
    user_id = int(callback.data.split(":")[1])

    if callback.from_user.id != user_id:
        await callback.answer("⛔ Это меню не для вас.", show_alert=True)
        return

    account = await get_bank_account(db, user_id)
    if account["deposit"] == 0:
        await callback.answer("❌ У вас нет депозита.", show_alert=True)
        return

    if get_now() < account["last_interest"]:
        await callback.answer("⏳ Срок депозита ещё не истёк.", show_alert=True)
        return

    interest = int(account["deposit"] * (account["procent"] / 100))
    final_amount = account["deposit"] + interest

    await update_bank_account(db, user_id, deposit=0, deposit_start=None, last_interest=None, procent=None)
    await update_bank_account(
    db,
    user_id,
    balance=account["balance"] + final_amount,
    deposit=0,
    deposit_start=None,
    last_interest=None,
    procent=None
    )

    await callback.message.edit_text(
        f"✅ Депозит завершён. Начислено {interest} PaketCoin процентов!",
        parse_mode=ParseMode.HTML,
        reply_markup=deposit_keyboard(user_id, await get_bank_account(db, user_id))
    )
    await callback.answer()